export type GameMode = "online" | "ai";
export type PlayerRole = "host" | "guest" | "ai";

export type Session = {
  mode: GameMode;
  role: PlayerRole;
  roomCode: string;
  name: string;
};
