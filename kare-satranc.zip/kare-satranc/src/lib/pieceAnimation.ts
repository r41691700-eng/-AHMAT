import { Chess } from "chess.js";
import type { Color, Move, PieceSymbol } from "chess.js";

/**
 * Presentation-only helpers.
 *
 * Game rules, move validation and networking stay in GameRoom / chess.js.
 * Here we replay the SAN history just to give every physical piece a stable
 * identity, so React can keep the same DOM node while it travels from one
 * square to another. That is what makes the smooth slide animation possible.
 */

export type TrackedPiece = {
  id: string;
  type: PieceSymbol;
  color: Color;
  square: string;
};

export type CapturedPiece = TrackedPiece;

export type MoveTrace = {
  from: string;
  to: string;
  san: string;
  color: Color;
  piece: PieceSymbol;
  captured: CapturedPiece[];
  movedIds: string[];
  promotion?: PieceSymbol;
};

export type TrackedBoard = {
  pieces: TrackedPiece[];
  lastMove: MoveTrace | null;
  /** False when an exotic position could not be replayed; pieces still render. */
  synchronized: boolean;
};

function initialPieces(game: Chess): TrackedPiece[] {
  const pieces: TrackedPiece[] = [];
  for (const row of game.board()) {
    for (const cell of row) {
      if (!cell) continue;
      pieces.push({
        id: `${cell.color}-${cell.type}-${cell.square}`,
        type: cell.type,
        color: cell.color,
        square: cell.square,
      });
    }
  }
  return pieces;
}

function bySquare(pieces: TrackedPiece[], square: string): TrackedPiece | undefined {
  return pieces.find((piece) => piece.square === square);
}

function moveRook(
  pieces: TrackedPiece[],
  from: string,
  to: string,
  movedIds: string[]
): void {
  const rook = bySquare(pieces, from);
  if (!rook) return;
  rook.square = to;
  movedIds.push(rook.id);
}

export function trackPieces(history: string[]): TrackedBoard {
  const game = new Chess();
  const pieces = initialPieces(game);
  let lastMove: MoveTrace | null = null;

  for (const san of history) {
    let move: Move;
    try {
      move = game.move(san) as Move;
    } catch {
      break;
    }
    if (!move) break;

    const moving = bySquare(pieces, move.from);
    if (!moving) break;

    const captured: CapturedPiece[] = [];
    const capturedSquare = move.flags.includes("e")
      ? `${move.to[0]}${move.from[1]}`
      : move.captured
        ? move.to
        : null;

    if (capturedSquare) {
      const victim = bySquare(pieces, capturedSquare);
      if (victim) {
        captured.push({ ...victim });
        pieces.splice(pieces.indexOf(victim), 1);
      }
    }

    const movedIds = [moving.id];
    moving.square = move.to;
    if (move.promotion) moving.type = move.promotion;

    // Castling keeps the rook's identity so it glides alongside the king.
    const rank = move.from[1];
    if (move.flags.includes("k")) moveRook(pieces, `h${rank}`, `f${rank}`, movedIds);
    if (move.flags.includes("q")) moveRook(pieces, `a${rank}`, `d${rank}`, movedIds);

    lastMove = {
      from: move.from,
      to: move.to,
      san: move.san,
      color: move.color,
      piece: move.piece,
      captured,
      movedIds,
      promotion: move.promotion as PieceSymbol | undefined,
    };
  }

  // Safety net: never draw a board that disagrees with the game engine.
  const expected = new Map<string, { type: PieceSymbol; color: Color }>();
  for (const row of game.board()) {
    for (const cell of row) {
      if (cell) expected.set(cell.square, { type: cell.type, color: cell.color });
    }
  }
  const synchronized =
    expected.size === pieces.length &&
    pieces.every((piece) => {
      const actual = expected.get(piece.square);
      return actual && actual.type === piece.type && actual.color === piece.color;
    });

  if (!synchronized) {
    const fallback: TrackedPiece[] = [];
    expected.forEach(({ type, color }, square) => {
      fallback.push({ id: `${color}-${type}-${square}`, type, color, square });
    });
    return { pieces: fallback, lastMove, synchronized: false };
  }

  return { pieces, lastMove, synchronized: true };
}

/** Converts an algebraic square into grid offsets for the active orientation. */
export function squareOffsets(square: string, orientation: Color) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  const col = orientation === "w" ? file : 7 - file;
  const row = orientation === "w" ? 8 - rank : rank - 1;
  return { col, row };
}
