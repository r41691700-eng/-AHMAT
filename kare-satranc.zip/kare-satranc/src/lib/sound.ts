type SoundKind = "move" | "capture" | "check" | "notify" | "win" | "lose" | "join";

let context: AudioContext | null = null;

function getContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AudioCtor =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtor) return null;
  if (!context) context = new AudioCtor();
  if (context.state === "suspended") void context.resume();
  return context;
}

function tone(
  ctx: AudioContext,
  frequency: number,
  start: number,
  duration: number,
  volume: number,
  type: OscillatorType = "sine"
) {
  const oscillator = ctx.createOscillator();
  const gain = ctx.createGain();
  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, ctx.currentTime + start);
  gain.gain.setValueAtTime(0, ctx.currentTime + start);
  gain.gain.linearRampToValueAtTime(volume, ctx.currentTime + start + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + duration);
  oscillator.connect(gain);
  gain.connect(ctx.destination);
  oscillator.start(ctx.currentTime + start);
  oscillator.stop(ctx.currentTime + start + duration + 0.02);
}

export function playSound(kind: SoundKind, enabled = true) {
  if (!enabled) return;
  const ctx = getContext();
  if (!ctx) return;
  try {
    switch (kind) {
      case "move":
        tone(ctx, 320, 0, 0.09, 0.055, "triangle");
        tone(ctx, 190, 0.02, 0.1, 0.035, "sine");
        break;
      case "capture":
        tone(ctx, 180, 0, 0.12, 0.075, "square");
        tone(ctx, 120, 0.035, 0.13, 0.045, "triangle");
        break;
      case "check":
        tone(ctx, 660, 0, 0.12, 0.05, "triangle");
        tone(ctx, 880, 0.1, 0.16, 0.045, "triangle");
        break;
      case "notify":
        tone(ctx, 520, 0, 0.1, 0.04, "sine");
        tone(ctx, 780, 0.09, 0.12, 0.035, "sine");
        break;
      case "join":
        tone(ctx, 440, 0, 0.1, 0.04, "sine");
        tone(ctx, 660, 0.09, 0.1, 0.04, "sine");
        tone(ctx, 880, 0.18, 0.16, 0.04, "sine");
        break;
      case "win":
        tone(ctx, 523, 0, 0.16, 0.05, "sine");
        tone(ctx, 659, 0.14, 0.16, 0.05, "sine");
        tone(ctx, 784, 0.28, 0.22, 0.05, "sine");
        break;
      case "lose":
        tone(ctx, 392, 0, 0.18, 0.045, "sine");
        tone(ctx, 311, 0.16, 0.22, 0.045, "sine");
        break;
    }
  } catch {
    /* audio is a nice-to-have, never break the game */
  }
}
