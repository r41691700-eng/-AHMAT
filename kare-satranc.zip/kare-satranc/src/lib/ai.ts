import { Chess, type Color, type Move, type PieceSymbol } from "chess.js";

const VALUE: Record<PieceSymbol, number> = {
  p: 100,
  n: 320,
  b: 335,
  r: 500,
  q: 900,
  k: 0,
};

const CENTER_BONUS: Record<PieceSymbol, number> = {
  p: 0,
  n: 26,
  b: 14,
  r: 4,
  q: 10,
  k: 0,
};

function squareCenter(square: string): number {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]) - 1;
  const fileDistance = Math.abs(3.5 - file);
  const rankDistance = Math.abs(3.5 - rank);
  return 7 - (fileDistance + rankDistance);
}

function pawnAdvancement(square: string, color: Color): number {
  const rank = Number(square[1]);
  const progress = color === "w" ? rank - 2 : 7 - rank;
  return progress * 7;
}

/** Static evaluation, positive numbers favour white. */
export function evaluate(game: Chess): number {
  let score = 0;
  for (const row of game.board()) {
    for (const cell of row) {
      if (!cell) continue;
      const sign = cell.color === "w" ? 1 : -1;
      let value = VALUE[cell.type];
      const center = squareCenter(cell.square);
      value += center * CENTER_BONUS[cell.type];
      if (cell.type === "p") value += pawnAdvancement(cell.square, cell.color);
      score += sign * value;
    }
  }
  return score;
}

function orderMoves(moves: Move[]): Move[] {
  return [...moves].sort((a, b) => {
    const score = (move: Move) =>
      (move.captured ? VALUE[move.captured as PieceSymbol] : 0) +
      (move.promotion ? 800 : 0) +
      (move.san.includes("+") ? 40 : 0);
    return score(b) - score(a);
  });
}

function search(game: Chess, depth: number, alpha: number, beta: number): number {
  if (game.isGameOver()) {
    if (game.isCheckmate()) {
      return game.turn() === "w" ? -100000 - depth : 100000 + depth;
    }
    return 0;
  }
  if (depth === 0) return evaluate(game);

  const moves = orderMoves(game.moves({ verbose: true }) as Move[]);
  if (game.turn() === "w") {
    let best = -Infinity;
    for (const move of moves) {
      game.move(move);
      best = Math.max(best, search(game, depth - 1, alpha, beta));
      game.undo();
      alpha = Math.max(alpha, best);
      if (beta <= alpha) break;
    }
    return best;
  }
  let best = Infinity;
  for (const move of moves) {
    game.move(move);
    best = Math.min(best, search(game, depth - 1, alpha, beta));
    game.undo();
    beta = Math.min(beta, best);
    if (beta <= alpha) break;
  }
  return best;
}

export type SimpleMove = {
  from: string;
  to: string;
  promotion?: string;
};

/** Chooses a reasonable move for the side whose turn it is (used for black). */
export function findBestMove(history: string[], depth = 2): SimpleMove | null {
  const game = new Chess();
  for (const san of history) {
    try {
      game.move(san);
    } catch {
      return null;
    }
  }
  const moves = orderMoves(game.moves({ verbose: true }) as Move[]);
  if (moves.length === 0) return null;

  const scored: { move: Move; score: number }[] = [];
  for (const move of moves) {
    game.move(move);
    const score = search(game, depth - 1, -Infinity, Infinity);
    game.undo();
    scored.push({ move, score });
  }

  // A little noise keeps the computer from playing the same game every time.
  const isBlack = game.turn() === "b";
  scored.sort((a, b) => (isBlack ? a.score - b.score : b.score - a.score));
  const bestScore = scored[0].score;
  const tolerance = 35;
  const contenders = scored.filter(({ score }) =>
    isBlack ? score <= bestScore + tolerance : score >= bestScore - tolerance
  );
  const pick = contenders[Math.floor(Math.random() * Math.min(2, contenders.length))];
  const chosen = pick?.move ?? scored[0].move;

  return {
    from: chosen.from,
    to: chosen.to,
    promotion: chosen.promotion,
  };
}
