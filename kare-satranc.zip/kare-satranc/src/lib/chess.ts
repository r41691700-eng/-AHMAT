import { Chess, type Color, type Move, type PieceSymbol } from "chess.js";

export type { Color, PieceSymbol, Move };
export type SquareName = string;

export const PIECE_GLYPH: Record<PieceSymbol, string> = {
  p: "♟",
  n: "♞",
  b: "♝",
  r: "♜",
  q: "♛",
  k: "♚",
};

export const PIECE_NAME_TR: Record<PieceSymbol, string> = {
  p: "Piyon",
  n: "At",
  b: "Fil",
  r: "Kale",
  q: "Vezir",
  k: "Şah",
};

export const PIECE_VALUE: Record<PieceSymbol, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
  k: 0,
};

export const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;
export const RANKS = ["8", "7", "6", "5", "4", "3", "2", "1"] as const;

export function opposite(color: Color): Color {
  return color === "w" ? "b" : "w";
}

export function colorName(color: Color): string {
  return color === "w" ? "Beyaz" : "Siyah";
}

/** Rebuild a chess position from a SAN history. Never mutates shared state. */
export function buildGame(history: string[]): Chess {
  const game = new Chess();
  for (const san of history) {
    try {
      game.move(san);
    } catch {
      break;
    }
  }
  return game;
}

export function verboseMoves(history: string[]): Move[] {
  return buildGame(history).history({ verbose: true }) as Move[];
}

export type GameResult = {
  over: boolean;
  winner: Color | null;
  kind: "checkmate" | "resign" | "agreed" | "draw" | "active";
  title: string;
  detail: string;
};

export function getResult(
  game: Chess,
  resignWinner: Color | null = null,
  agreedDraw = false
): GameResult {
  if (resignWinner) {
    return {
      over: true,
      winner: resignWinner,
      kind: "resign",
      title: `${colorName(resignWinner)} kazandı`,
      detail: "Rakip maçtan çekildi.",
    };
  }
  if (agreedDraw) {
    return {
      over: true,
      winner: null,
      kind: "agreed",
      title: "Berabere",
      detail: "İki taraf da beraberliği kabul etti.",
    };
  }
  if (game.isCheckmate()) {
    const winner = opposite(game.turn());
    return {
      over: true,
      winner,
      kind: "checkmate",
      title: `${colorName(winner)} kazandı`,
      detail: "Şah mat. Tahtada hamle kalmadı.",
    };
  }
  if (game.isStalemate()) {
    return {
      over: true,
      winner: null,
      kind: "draw",
      title: "Berabere",
      detail: "Pat! Şah tehdit altında değil ama hamle de yok.",
    };
  }
  if (game.isInsufficientMaterial()) {
    return {
      over: true,
      winner: null,
      kind: "draw",
      title: "Berabere",
      detail: "Mat için yeterli materyal kalmadı.",
    };
  }
  if (game.isThreefoldRepetition()) {
    return {
      over: true,
      winner: null,
      kind: "draw",
      title: "Berabere",
      detail: "Aynı pozisyon üç kez tekrarlandı.",
    };
  }
  if (game.isDrawByFiftyMoves()) {
    return {
      over: true,
      winner: null,
      kind: "draw",
      title: "Berabere",
      detail: "50 hamle kuralı devreye girdi.",
    };
  }
  if (game.isDraw()) {
    return {
      over: true,
      winner: null,
      kind: "draw",
      title: "Berabere",
      detail: "Oyun berabere sonuçlandı.",
    };
  }
  return {
    over: false,
    winner: null,
    kind: "active",
    title: game.isCheck() ? "Şah!" : "Oyun devam ediyor",
    detail: "",
  };
}

export type Captures = { byWhite: PieceSymbol[]; byBlack: PieceSymbol[] };

export function getCaptures(history: string[]): Captures {
  const game = new Chess();
  const captures: Captures = { byWhite: [], byBlack: [] };
  for (const san of history) {
    try {
      const move = game.move(san);
      if (move?.captured) {
        if (move.color === "w") captures.byWhite.push(move.captured);
        else captures.byBlack.push(move.captured);
      }
    } catch {
      break;
    }
  }
  return captures;
}

export function materialScore(captures: Captures): number {
  const sum = (list: PieceSymbol[]) =>
    list.reduce((total, piece) => total + PIECE_VALUE[piece], 0);
  return sum(captures.byWhite) - sum(captures.byBlack);
}

export function sortCaptures(list: PieceSymbol[]): PieceSymbol[] {
  return [...list].sort((a, b) => PIECE_VALUE[b] - PIECE_VALUE[a]);
}

export type MoveRow = {
  number: number;
  white?: { san: string; move: Move };
  black?: { san: string; move: Move };
};

export function groupMoves(moves: Move[]): MoveRow[] {
  const rows: MoveRow[] = [];
  moves.forEach((move, index) => {
    if (index % 2 === 0) {
      rows.push({ number: Math.floor(index / 2) + 1, white: { san: move.san, move } });
    } else {
      rows[rows.length - 1].black = { san: move.san, move };
    }
  });
  return rows;
}

const OPENINGS: { moves: string[]; name: string }[] = [
  { moves: ["e4", "e5", "Nf3", "Nc6", "Bc4", "Bc5"], name: "Giuoco Piano" },
  { moves: ["e4", "e5", "Nf3", "Nc6", "Bc4"], name: "İtalyan Açılışı" },
  { moves: ["e4", "e5", "Nf3", "Nc6", "Bb5"], name: "İspanyol Açılışı" },
  { moves: ["e4", "e5", "Nf3", "Nc6", "d4"], name: "İskoç Açılışı" },
  { moves: ["e4", "e5", "f4"], name: "Kral Gambiti" },
  { moves: ["e4", "e5"], name: "Açık Oyun" },
  { moves: ["e4", "c5"], name: "Sicilya Savunması" },
  { moves: ["e4", "e6"], name: "Fransız Savunması" },
  { moves: ["e4", "c6"], name: "Karo-Kann Savunması" },
  { moves: ["e4", "d5"], name: "İskandinav Savunması" },
  { moves: ["e4", "d6"], name: "Pirc Savunması" },
  { moves: ["d4", "d5", "c4"], name: "Vezir Gambiti" },
  { moves: ["d4", "Nf6", "c4", "g6"], name: "Kral Hindi" },
  { moves: ["d4", "Nf6", "c4", "e6"], name: "Nimzo-Hindi" },
  { moves: ["d4", "d5"], name: "Kapalı Oyun" },
  { moves: ["d4", "Nf6"], name: "Hint Sistemi" },
  { moves: ["c4"], name: "İngiliz Açılışı" },
  { moves: ["Nf3"], name: "Réti Açılışı" },
  { moves: ["e4"], name: "Kral Piyonu Açılışı" },
  { moves: ["d4"], name: "Vezir Piyonu Açılışı" },
];

export function detectOpening(history: string[]): string {
  if (history.length === 0) return "Yeni oyun";
  for (const opening of OPENINGS) {
    if (history.length < opening.moves.length) continue;
    if (opening.moves.every((san, i) => history[i] === san)) return opening.name;
  }
  return "Serbest oyun";
}

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateRoomCode(length = 6): string {
  const bytes = new Uint8Array(length);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
  }
  return Array.from(bytes, (byte) => CODE_ALPHABET[byte % CODE_ALPHABET.length]).join("");
}

export function normalizeRoomCode(input: string): string {
  return input.replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 6);
}

export function peerIdForRoom(code: string): string {
  return `kare-satranc-v1-${code.toLowerCase()}`;
}

export function shareLinkForRoom(code: string): string {
  if (typeof window === "undefined") return `#oda=${code}`;
  return `${window.location.origin}${window.location.pathname}?oda=${code}`;
}

export function readCodeFromUrl(): string | null {
  if (typeof window === "undefined") return null;
  const params = new URLSearchParams(window.location.search);
  const raw = params.get("oda") ?? params.get("room");
  if (!raw) return null;
  const code = normalizeRoomCode(raw);
  return code.length === 6 ? code : null;
}

export function pieceAt(game: Chess, square: string) {
  return game.get(square as Parameters<Chess["get"]>[0]);
}

export function isPromotionMove(game: Chess, from: string, to: string): boolean {
  const options = game.moves({ square: from as never, verbose: true });
  return options.some(
    (move) =>
      move.to === to &&
      (move.promotion !== undefined || move.flags.includes("p"))
  );
}
