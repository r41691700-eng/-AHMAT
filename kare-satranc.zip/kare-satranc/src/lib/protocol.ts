import type { Color } from "chess.js";

export type NetMessage =
  | { t: "hello"; name: string }
  | { t: "welcome"; name: string; history: string[] }
  | { t: "move"; history: string[] }
  | { t: "chat"; id: string; name: string; color: Color; text: string }
  | { t: "draw-offer" }
  | { t: "draw-accept" }
  | { t: "draw-decline" }
  | { t: "resign" }
  | { t: "rematch-offer" }
  | { t: "rematch-accept" }
  | { t: "rematch-decline" }
  | { t: "resync"; history: string[] }
  | { t: "ping" };

export function isNetMessage(value: unknown): value is NetMessage {
  if (typeof value !== "object" || value === null) return false;
  const record = value as Record<string, unknown>;
  return typeof record.t === "string";
}

export type ChatEntry = {
  id: string;
  author: "me" | "opponent" | "system";
  name: string;
  text: string;
  time: number;
  color?: Color;
};
