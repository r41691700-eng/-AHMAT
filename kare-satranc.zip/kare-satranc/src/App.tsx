import { useEffect, useState } from "react";
import { GameRoom } from "@/components/GameRoom";
import { HomeScreen } from "@/components/HomeScreen";
import { generateRoomCode, readCodeFromUrl } from "@/lib/chess";
import type { Session } from "@/lib/session";

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [inviteCode, setInviteCode] = useState<string | null>(() => readCodeFromUrl());

  useEffect(() => {
    if (session) window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    document.title = session ? "KARE · Oyun Masası" : "KARE · İki Kişilik Online Satranç";
  }, [session]);

  const createRoom = (name: string) => {
    setInviteCode(null);
    setSession({
      mode: "online",
      role: "host",
      roomCode: generateRoomCode(),
      name,
    });
  };

  const joinRoom = (code: string, name: string) => {
    setSession({ mode: "online", role: "guest", roomCode: code, name });
  };

  const playAI = (name: string) => {
    setSession({ mode: "ai", role: "ai", roomCode: "BOT", name });
  };

  const switchToAI = () => {
    setSession((current) => ({
      mode: "ai",
      role: "ai",
      roomCode: "BOT",
      name: current?.name ?? "Oyuncu",
    }));
  };

  const exitToHome = () => {
    setSession(null);
    setInviteCode(readCodeFromUrl());
  };

  if (!session) {
    return (
      <HomeScreen
        onCreate={createRoom}
        onJoin={joinRoom}
        onPlayAI={playAI}
        initialCode={inviteCode}
      />
    );
  }

  return (
    <GameRoom
      key={`${session.mode}-${session.role}-${session.roomCode}`}
      session={session}
      onExit={exitToHome}
      onSwitchAI={switchToAI}
    />
  );
}
