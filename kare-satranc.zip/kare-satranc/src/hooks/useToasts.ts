import { useCallback, useRef, useState } from "react";
import type { ToastItem, ToastTone } from "@/components/ui";

export function useToasts() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const timers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  const dismiss = useCallback((id: string) => {
    setToasts((current) => current.filter((toast) => toast.id !== id));
    const timer = timers.current[id];
    if (timer) {
      clearTimeout(timer);
      delete timers.current[id];
    }
  }, []);

  const push = useCallback(
    (title: string, options?: { description?: string; tone?: ToastTone; duration?: number }) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const item: ToastItem = {
        id,
        title,
        description: options?.description,
        tone: options?.tone ?? "neutral",
      };
      setToasts((current) => [...current.slice(-2), item]);
      timers.current[id] = setTimeout(
        () => {
          setToasts((current) => current.filter((toast) => toast.id !== id));
          delete timers.current[id];
        },
        options?.duration ?? 3800
      );
      return id;
    },
    []
  );

  return { toasts, push, dismiss };
}
