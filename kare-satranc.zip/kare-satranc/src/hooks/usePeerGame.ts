import { useCallback, useEffect, useRef, useState } from "react";
import Peer, { type DataConnection } from "peerjs";
import { peerIdForRoom } from "@/lib/chess";
import { isNetMessage, type NetMessage } from "@/lib/protocol";

export type PeerPhase =
  | "idle"
  | "connecting"
  | "waiting"
  | "connected"
  | "disconnected"
  | "error";

type Options = {
  roomCode: string;
  role: "host" | "guest";
  name: string;
  enabled?: boolean;
  onMessage: (message: NetMessage) => void;
  onOpen: (remoteName?: string) => void;
  onClose: () => void;
};

const PEER_OPTIONS = {
  debug: 0,
  config: {
    iceServers: [
      { urls: "stun:stun.cloudflare.com:3478" },
      { urls: "stun:stun.l.google.com:19302" },
      { urls: "stun:stun1.l.google.com:19302" },
    ],
  },
};

function describePeerError(type: string): string {
  switch (type) {
    case "peer-unavailable":
      return "Bu kodla açık bir oda bulunamadı. Kodu kontrol et veya yeni bir oda kur.";
    case "unavailable-id":
      return "Oda kodu şu anda kullanımda. Birkaç saniye içinde yeni bir kodla tekrar dene.";
    case "browser-incompatible":
      return "Tarayıcın WebRTC desteklemiyor. Güncel bir Chrome, Edge veya Safari dene.";
    case "network":
    case "server-error":
    case "socket-error":
    case "socket-closed":
      return "Eşleşme sunucusuna ulaşılamadı. Ağını kontrol et veya bilgisayara karşı oyna.";
    case "webrtc":
      return "İki cihaz arasında doğrudan bağlantı kurulamadı. Farklı bir ağda tekrar dene.";
    default:
      return "Bağlantı sırasında bir sorun oluştu. Lütfen tekrar dene.";
  }
}

/**
 * Real-time, serverless two-player transport built on PeerJS (WebRTC).
 * The room creator owns a deterministic peer id derived from the 6-char room code,
 * the joiner dials that id. Moves flow over an encrypted data channel.
 */
export function usePeerGame({
  roomCode,
  role,
  name,
  enabled = true,
  onMessage,
  onOpen,
  onClose,
}: Options) {
  const [phase, setPhase] = useState<PeerPhase>(enabled ? "connecting" : "idle");
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [remoteName, setRemoteName] = useState<string | undefined>(undefined);

  const peerRef = useRef<Peer | null>(null);
  const connRef = useRef<DataConnection | null>(null);
  const callbacks = useRef({ onMessage, onOpen, onClose });
  callbacks.current = { onMessage, onOpen, onClose };

  const retry = useCallback(() => {
    setError(null);
    setPhase("connecting");
    setAttempt((value) => value + 1);
  }, []);

  const send = useCallback((message: NetMessage) => {
    const conn = connRef.current;
    if (conn?.open) {
      try {
        conn.send(message);
        return true;
      } catch {
        return false;
      }
    }
    return false;
  }, []);

  useEffect(() => {
    if (!enabled) {
      setPhase("idle");
      return;
    }

    let alive = true;
    let idRetries = 0;
    let connectTimer: ReturnType<typeof setTimeout> | undefined;
    let retryTimer: ReturnType<typeof setTimeout> | undefined;

    setPhase("connecting");
    setError(null);

    const initTimer = setTimeout(() => {
      if (!alive || peerRef.current?.open) return;
      fail(
        role === "guest"
          ? "Eşleşme sunucusuna ulaşılamadı. Ağını kontrol et veya bilgisayara karşı oyna."
          : "Oda sunucusu yanıt vermedi. Ağını kontrol edip yeniden deneyebilirsin."
      );
    }, 14000);

    const fail = (message: string) => {
      if (!alive) return;
      setError(message);
      setPhase("error");
    };

    const attachConnection = (conn: DataConnection) => {
      connRef.current = conn;
      setRemoteName(
        typeof conn.metadata?.name === "string" ? (conn.metadata.name as string) : undefined
      );

      conn.on("open", () => {
        if (!alive) return;
        if (connectTimer) clearTimeout(connectTimer);
        setPhase("connected");
        setError(null);
        callbacks.current.onOpen(
          typeof conn.metadata?.name === "string" ? (conn.metadata.name as string) : undefined
        );
      });

      conn.on("data", (data) => {
        if (!alive) return;
        if (isNetMessage(data)) callbacks.current.onMessage(data);
      });

      conn.on("close", () => {
        if (!alive) return;
        if (connRef.current === conn) connRef.current = null;
        setPhase("disconnected");
        callbacks.current.onClose();
      });

      conn.on("error", () => {
        if (!alive) return;
        setError("Veri kanalında bir sorun oluştu. Yeniden bağlanmayı deneyebilirsin.");
      });
    };

    const createHost = () => {
      const peer = new Peer(peerIdForRoom(roomCode), PEER_OPTIONS);
      peerRef.current = peer;

      peer.on("open", () => {
        if (!alive) return;
        setPhase("waiting");
      });

      peer.on("connection", (conn) => {
        if (!alive) return;
        if (connRef.current && connRef.current !== conn) {
          // One table per room: politely close extra connections.
          try {
            conn.close();
          } catch {
            /* noop */
          }
          return;
        }
        attachConnection(conn);
      });

      peer.on("error", (err) => {
        if (!alive) return;
        if (err.type === "unavailable-id" && idRetries < 4) {
          idRetries += 1;
          try {
            peer.destroy();
          } catch {
            /* noop */
          }
          retryTimer = setTimeout(() => {
            if (alive) createHost();
          }, 900 * idRetries);
          return;
        }
        if (err.type === "peer-unavailable") return;
        fail(describePeerError(err.type));
      });
    };

    const createGuest = () => {
      const peer = new Peer(PEER_OPTIONS);
      peerRef.current = peer;

      peer.on("open", () => {
        if (!alive) return;
        const conn = peer.connect(peerIdForRoom(roomCode), {
          reliable: true,
          metadata: { name },
        });
        attachConnection(conn);

        connectTimer = setTimeout(() => {
          if (alive && !connRef.current?.open) {
            fail("Odaya ulaşılamadı. Kodu kontrol et veya birkaç saniye sonra tekrar dene.");
          }
        }, 16000);
      });

      peer.on("error", (err) => {
        if (!alive) return;
        fail(describePeerError(err.type));
      });
    };

    if (role === "host") createHost();
    else createGuest();

    return () => {
      alive = false;
      if (connectTimer) clearTimeout(connectTimer);
      if (retryTimer) clearTimeout(retryTimer);
      clearTimeout(initTimer);
      const conn = connRef.current;
      connRef.current = null;
      try {
        conn?.close();
      } catch {
        /* noop */
      }
      const peer = peerRef.current;
      peerRef.current = null;
      try {
        peer?.destroy();
      } catch {
        /* noop */
      }
    };
    // `attempt` intentionally re-runs the transport after a manual retry.
  }, [roomCode, role, name, attempt, enabled]);

  return { phase, error, remoteName, send, retry };
}
