import { useEffect } from "react";
import { createPortal } from "react-dom";
import { Check, Crown, Info, TriangleAlert, X } from "lucide-react";
import { cn } from "@/utils/cn";

export function KnightMark({ className }: { className?: string }) {
  return (
    <span
      aria-hidden
      className={cn("select-none leading-none font-normal", className)}
      style={{ fontFamily: '"Noto Sans Symbols 2", serif', fontSize: "inherit" }}
    >
      ♞
    </span>
  );
}

export function Logo({
  onClick,
  subtitle = true,
  size = "md",
}: {
  onClick?: () => void;
  subtitle?: boolean;
  size?: "sm" | "md";
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex items-center gap-3 text-left"
      aria-label="Kare ana sayfa"
    >
      <span
        className={cn(
          "relative grid place-items-center rounded-[11px] border border-brass-300/35 bg-gradient-to-br from-ink-700 to-ink-850 shadow-[0_1px_0_rgba(255,255,255,.1)_inset,0_8px_18px_-10px_rgba(0,0,0,.9)] transition-transform group-hover:-translate-y-0.5",
          size === "md" ? "h-10 w-10" : "h-9 w-9"
        )}
      >
        <KnightMark
          className={cn(
            "relative -mt-px block leading-none text-brass-200 [text-shadow:0_1px_1px_rgba(0,0,0,.6)]",
            size === "md" ? "text-[26px]" : "text-[23px]"
          )}
        />
        <span className="absolute right-1.5 bottom-1.5 h-1 w-1 rounded-full bg-live/80" />
      </span>
      <span className="flex flex-col">
        <span
          className={cn(
            "font-display leading-none font-semibold tracking-[0.24em] text-cream",
            size === "md" ? "text-[19px]" : "text-[17px]"
          )}
        >
          KARE
        </span>
        {subtitle && (
          <span className="mt-1 text-[8.5px] font-bold tracking-[0.22em] text-muted/80 uppercase">
            Satranç Kulübü
          </span>
        )}
      </span>
    </button>
  );
}

export type ToastTone = "gold" | "green" | "red" | "neutral";
export type ToastItem = {
  id: string;
  title: string;
  description?: string;
  tone?: ToastTone;
};

const toneStyles: Record<ToastTone, { icon: typeof Info; className: string }> = {
  gold: { icon: Crown, className: "border-brass-300/30 bg-[#1b1a12]/95 text-brass-200" },
  green: { icon: Check, className: "border-live/25 bg-[#101b13]/95 text-live" },
  red: { icon: TriangleAlert, className: "border-red-400/30 bg-[#1d1210]/95 text-red-300" },
  neutral: { icon: Info, className: "border-line bg-ink-800/95 text-cream" },
};

export function ToastStack({
  toasts,
  dismiss,
}: {
  toasts: ToastItem[];
  dismiss: (id: string) => void;
}) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="pointer-events-none fixed inset-x-0 top-4 z-[120] flex flex-col items-center gap-2 px-4 sm:inset-x-auto sm:right-5 sm:items-end">
      {toasts.map((toast) => {
        const tone = toneStyles[toast.tone ?? "neutral"];
        const Icon = tone.icon;
        return (
          <div
            key={toast.id}
            role="status"
            className={cn(
              "animate-toast pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-xl border px-4 py-3 shadow-[0_24px_60px_-30px_rgba(0,0,0,.9)] backdrop-blur-xl",
              tone.className
            )}
          >
            <Icon className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2.2} />
            <div className="min-w-0 flex-1">
              <p className="text-[13px] leading-tight font-bold text-cream">{toast.title}</p>
              {toast.description && (
                <p className="mt-0.5 text-[11.5px] leading-snug text-muted">{toast.description}</p>
              )}
            </div>
            <button
              type="button"
              onClick={() => dismiss(toast.id)}
              className="rounded p-0.5 text-muted transition hover:text-cream"
              aria-label="Bildirimi kapat"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      })}
    </div>,
    document.body
  );
}

export function Modal({
  open,
  onClose,
  title,
  eyebrow,
  children,
  hideClose = false,
  width = "max-w-md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  eyebrow?: string;
  children: React.ReactNode;
  hideClose?: boolean;
  width?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[110] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <button
        type="button"
        aria-label="Pencereyi kapat"
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-ink-950/75 backdrop-blur-md"
      />
      <div
        className={cn(
          "animate-pop glass relative w-full overflow-hidden rounded-3xl p-6 shadow-2xl",
          width
        )}
      >
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            {eyebrow && <p className="eyebrow mb-1.5">{eyebrow}</p>}
            <h2 className="font-display text-2xl leading-tight font-semibold text-cream">{title}</h2>
          </div>
          {!hideClose && (
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-line/70 p-2 text-muted transition hover:border-brass-300/30 hover:text-cream"
              aria-label="Kapat"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        {children}
      </div>
    </div>,
    document.body
  );
}

export function StatusDot({ state }: { state: "online" | "waiting" | "offline" | "error" }) {
  return (
    <span
      aria-hidden
      className={cn(
        "inline-block h-1.5 w-1.5 rounded-full",
        state === "online" && "live-dot bg-live",
        state === "waiting" && "animate-pulse bg-brass-300",
        state === "offline" && "bg-muted/50",
        state === "error" && "bg-red-400"
      )}
    />
  );
}
