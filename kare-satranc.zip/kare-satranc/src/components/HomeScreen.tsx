import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  Bot,
  Check,
  Crown,
  KeyRound,
  MessageSquare,
  ShieldCheck,
  Sparkles,
  Swords,
  User,
  Users,
  X,
  Zap,
} from "lucide-react";
import { Logo } from "@/components/ui";
import { normalizeRoomCode } from "@/lib/chess";
import { cn } from "@/utils/cn";

type Props = {
  onCreate: (name: string) => void;
  onJoin: (code: string, name: string) => void;
  onPlayAI: (name: string) => void;
  initialCode?: string | null;
};

const MINI_PIECES: Record<number, { glyph: string; color: "w" | "b" }> = {
  1: { glyph: "♜", color: "b" },
  2: { glyph: "♞", color: "b" },
  4: { glyph: "♟", color: "b" },
  7: { glyph: "♟", color: "b" },
  9: { glyph: "♟", color: "w" },
  11: { glyph: "♞", color: "w" },
  13: { glyph: "♛", color: "w" },
  14: { glyph: "♚", color: "w" },
};

function MiniBoardPreview() {
  return (
    <div className="relative hidden w-full max-w-[380px] lg:block">
      <div className="absolute -top-8 -left-6 h-28 w-28 rounded-full bg-brass-400/10 blur-3xl" />
      <div className="animate-float">
        <div className="relative rotate-[-2.5deg] rounded-2xl border border-line/80 bg-ink-800/90 p-3.5 shadow-[0_40px_70px_-40px_rgba(0,0,0,0.95)] backdrop-blur-sm">
          <div className="mb-2.5 flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-live" />
              <span className="text-[10px] font-bold tracking-[0.18em] text-muted uppercase">
                Oda #X8K2M9
              </span>
            </div>
            <span className="rounded-full border border-brass-300/25 bg-brass-300/10 px-2 py-0.5 text-[9px] font-bold tracking-wider text-brass-200 uppercase">
              Canlı
            </span>
          </div>
          <div className="mini-board grid grid-cols-4">
            {Array.from({ length: 16 }).map((_, index) => {
              const row = Math.floor(index / 4);
              const col = index % 4;
              const isLight = (row + col) % 2 === 0;
              const piece = MINI_PIECES[index];
              return (
                <div
                  key={index}
                  className={cn("mini-sq", isLight ? "bg-[#e9dfcb]" : "bg-[#65806a]")}
                >
                  {piece && (
                    <span
                      className={cn(
                        "piece-mini !text-[27px]",
                        piece.color === "w" ? "piece-mini-w" : "piece-mini-b",
                        (index === 13 || index === 14) && "drop-shadow-md"
                      )}
                    >
                      {piece.glyph}
                    </span>
                  )}
                  {index === 13 && (
                    <span className="absolute h-[78%] w-[78%] rounded-sm border-2 border-brass-500/60 bg-brass-300/25" />
                  )}
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex items-center justify-between gap-2 px-0.5">
            <div className="flex items-center gap-2">
              <span className="grid h-6 w-6 place-items-center rounded-full border border-line bg-ink-700 text-[9px] font-bold text-cream">
                EY
              </span>
              <span className="text-[11px] font-semibold text-cream-dim">Eylül</span>
              <span className="text-[10px] text-muted">▲ 2</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-muted">▼ 2</span>
              <span className="text-[11px] font-semibold text-cream-dim">Kerem</span>
              <span className="grid h-6 w-6 place-items-center rounded-full border border-line bg-ink-700 text-[9px] font-bold text-cream">
                KE
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute -right-3 -bottom-5 rotate-[2deg] rounded-xl border border-live/20 bg-[#101b13]/95 px-3.5 py-2 shadow-xl backdrop-blur">
        <div className="flex items-center gap-2">
          <span className="live-dot h-1.5 w-1.5 rounded-full bg-live" />
          <span className="text-[11px] font-bold text-cream">Oyun başladı!</span>
          <span className="text-[10px] text-muted">Sıra beyazda</span>
        </div>
      </div>
    </div>
  );
}

export function HomeScreen({ onCreate, onJoin, onPlayAI, initialCode }: Props) {
  const [name, setName] = useState(() => {
    if (typeof window === "undefined") return "";
    return localStorage.getItem("kare:name") ?? "";
  });
  const [joinOpen, setJoinOpen] = useState(Boolean(initialCode));
  const [code, setCode] = useState(initialCode ? normalizeRoomCode(initialCode) : "");
  const [error, setError] = useState<string | null>(null);
  const codeRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialCode) {
      setJoinOpen(true);
      setCode(normalizeRoomCode(initialCode));
      setTimeout(() => codeRef.current?.focus(), 250);
    }
  }, [initialCode]);

  useEffect(() => {
    if (joinOpen) setTimeout(() => codeRef.current?.focus(), 60);
  }, [joinOpen]);

  const displayName = () => {
    const trimmed = name.trim().slice(0, 18);
    return trimmed || "Oyuncu";
  };

  const rememberName = () => {
    try {
      localStorage.setItem("kare:name", displayName());
    } catch {
      /* storage can be unavailable */
    }
  };

  const handleCreate = () => {
    rememberName();
    onCreate(displayName());
  };

  const handleJoin = (event?: React.FormEvent) => {
    event?.preventDefault();
    const normalized = normalizeRoomCode(code);
    if (normalized.length !== 6) {
      setError("Oda kodu 6 karakter olmalı. Örn: X8K2M9");
      return;
    }
    setError(null);
    rememberName();
    onJoin(normalized, displayName());
  };

  const handleAI = () => {
    rememberName();
    onPlayAI(displayName());
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* ambient decor */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute top-[-180px] left-[6%] h-[460px] w-[460px] rounded-full bg-sage-500/10 blur-[110px]" />
        <div className="absolute top-[120px] right-[-120px] h-[480px] w-[480px] rounded-full bg-brass-500/10 blur-[120px]" />
        <div
          className="absolute inset-0 opacity-[0.18]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(243,238,226,.055) 1px, transparent 1px), linear-gradient(90deg, rgba(243,238,226,.055) 1px, transparent 1px)",
            backgroundSize: "76px 76px",
            maskImage: "radial-gradient(ellipse at 50% 20%, black 10%, transparent 72%)",
            WebkitMaskImage: "radial-gradient(ellipse at 50% 20%, black 10%, transparent 72%)",
          }}
        />
        <span className="piece-mini absolute top-24 right-[4%] hidden !text-[220px] text-cream/[0.025] xl:block">
          ♞
        </span>
        <span className="piece-mini absolute bottom-40 left-[2%] hidden !text-[120px] text-brass-300/[0.05] xl:block">
          ♜
        </span>
      </div>

      <header className="relative z-20 border-b border-line/50">
        <div className="mx-auto flex h-[76px] w-full max-w-[1240px] items-center justify-between px-5 sm:px-8">
          <Logo />
          <nav className="hidden items-center gap-8 text-[13px] font-semibold text-cream-dim md:flex">
            <a href="#nasil" className="transition-colors hover:text-brass-200">
              Nasıl oynanır?
            </a>
            <a href="#ozellikler" className="transition-colors hover:text-brass-200">
              Özellikler
            </a>
            <a href="#kurallar" className="transition-colors hover:text-brass-200">
              Kurallar
            </a>
          </nav>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-2 rounded-full border border-line/80 bg-ink-800/60 px-3 py-1.5 text-[10.5px] font-bold tracking-wider text-muted uppercase sm:inline-flex">
              <span className="h-1.5 w-1.5 rounded-full bg-live" />
              Ücretsiz
            </span>
            <button
              type="button"
              onClick={handleAI}
              className="btn-ghost !px-3.5 !py-2 !text-[12px]"
            >
              <Bot className="h-4 w-4 text-brass-200" />
              <span className="hidden sm:inline">Bilgisayara karşı</span>
              <span className="sm:hidden">Bot</span>
            </button>
          </div>
        </div>
      </header>

      <main className="relative z-10 mx-auto w-full max-w-[1240px] px-5 sm:px-8">
        <section className="grid items-center gap-14 py-14 sm:py-16 lg:grid-cols-[1.06fr_0.94fr] lg:gap-16 lg:py-20">
          <div className="animate-fade-up lg:col-start-1 lg:row-start-1 lg:self-end">
            <div className="mb-6 inline-flex items-center gap-2.5 rounded-full border border-brass-300/20 bg-brass-300/[0.06] py-1.5 pr-4 pl-2">
              <span className="grid h-6 w-6 place-items-center rounded-full bg-brass-300/15">
                <Sparkles className="h-3 w-3 text-brass-200" />
              </span>
              <span className="text-[10.5px] font-bold tracking-[0.18em] text-brass-200 uppercase">
                İki kişilik · Gerçek zamanlı
              </span>
            </div>

            <h1 className="font-display text-[42px] leading-[1.02] font-medium tracking-[-0.02em] text-cream sm:text-[58px] lg:text-[64px]">
              Arkadaşınla satranç
              <br className="hidden sm:block" /> için{" "}
              <span className="relative inline-block italic text-brass-200">
                tek kod
                <svg
                  aria-hidden
                  viewBox="0 0 220 12"
                  className="absolute -bottom-2 left-0 w-full text-brass-400/50"
                  fill="none"
                >
                  <path d="M3 8C60 2 150 2 217 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
                </svg>
              </span>{" "}
              yeter.
            </h1>

            <p className="mt-7 max-w-[480px] text-[15px] leading-relaxed text-cream-dim/90 sm:text-base">
              Bir oda oluştur, 6 haneli kodu arkadaşınla paylaş. Gerçek zamanlı, tarayıcı
              üzerinden ve tamamen ücretsiz. Üyelik yok, indirme yok — sadece tahtanın başına geçin.
            </p>

          </div>

          <div className="animate-fade-up [animation-delay:120ms] lg:col-start-2 lg:row-span-2 lg:row-start-1 lg:self-center">
            <div className="glass relative overflow-hidden rounded-[26px] p-5 sm:p-7">
              <div className="pointer-events-none absolute -top-20 -right-16 h-52 w-52 rounded-full bg-brass-400/10 blur-3xl" />
              <div className="relative">
                <div className="mb-5 flex items-start justify-between">
                  <div>
                    <p className="eyebrow mb-1.5">Yeni maç</p>
                    <h2 className="font-display text-[25px] leading-tight font-semibold text-cream">
                      Masaya otur
                    </h2>
                  </div>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-line/80 bg-ink-900/70 px-2.5 py-1 text-[10px] font-bold tracking-wider text-muted uppercase">
                    <Crown className="h-3 w-3 text-brass-300" />
                    Kayıt yok
                  </span>
                </div>

                <label
                  htmlFor="player-name"
                  className="mb-1.5 block text-[11px] font-bold tracking-[0.12em] text-muted uppercase"
                >
                  Adın
                </label>
                <div className="relative">
                  <User className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-muted/70" />
                  <input
                    id="player-name"
                    type="text"
                    value={name}
                    maxLength={18}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="Oyuncu adın"
                    className="field !pl-10"
                    autoComplete="nickname"
                  />
                </div>

                <button type="button" onClick={handleCreate} className="btn-gold mt-3 w-full !py-3.5">
                  <Crown className="h-[18px] w-[18px]" strokeWidth={2.1} />
                  Oda Kur
                  <span className="ml-auto flex items-center gap-1.5 text-[10px] font-bold tracking-wider uppercase opacity-70">
                    Beyaz
                    <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </button>
                <p className="mt-2 text-center text-[10.5px] text-muted">
                  Kurucu beyaz taşlarla oynar · kodu sen paylaşırsın
                </p>

                <div className="divider-label my-4">veya</div>

                {!joinOpen ? (
                  <button
                    type="button"
                    onClick={() => {
                      setJoinOpen(true);
                      setError(null);
                    }}
                    className="btn-ghost w-full !py-3.5"
                  >
                    <KeyRound className="h-[17px] w-[17px] text-brass-200" />
                    Odaya Katıl
                    <span className="ml-auto text-[10px] font-bold tracking-wider text-muted uppercase">
                      Siyah
                    </span>
                  </button>
                ) : (
                  <form onSubmit={handleJoin} className="animate-pop">
                    <div className="mb-2 flex items-center justify-between">
                      <label
                        htmlFor="room-code"
                        className="text-[11px] font-bold tracking-[0.12em] text-muted uppercase"
                      >
                        Oda kodu
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          setJoinOpen(false);
                          setError(null);
                          setCode("");
                        }}
                        className="flex items-center gap-1 text-[10.5px] font-semibold text-muted transition hover:text-cream"
                      >
                        <X className="h-3 w-3" /> Vazgeç
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <input
                        id="room-code"
                        ref={codeRef}
                        value={code}
                        onChange={(event) => {
                          setCode(normalizeRoomCode(event.target.value));
                          setError(null);
                        }}
                        placeholder="X8K2M9"
                        inputMode="text"
                        autoCapitalize="characters"
                        autoComplete="off"
                        spellCheck={false}
                        aria-invalid={Boolean(error)}
                        className="field code-chip !py-3.5 text-center !text-[17px] font-bold uppercase placeholder:tracking-[0.3em] placeholder:text-muted/40"
                      />
                      <button
                        type="submit"
                        className="btn-gold shrink-0 !px-5"
                        disabled={code.length !== 6}
                        aria-label="Odaya katıl"
                      >
                        <ArrowRight className="h-[18px] w-[18px]" />
                      </button>
                    </div>
                    {error ? (
                      <p className="mt-2 text-[11px] font-semibold text-red-300">{error}</p>
                    ) : (
                      <p className="mt-2 text-center text-[10.5px] text-muted">
                        Katılan oyuncu siyah taşlarla oynar
                      </p>
                    )}
                  </form>
                )}

                <button
                  type="button"
                  onClick={handleAI}
                  className="group mt-4 flex w-full items-center justify-center gap-2 rounded-lg py-2 text-[11.5px] font-semibold text-muted transition hover:text-brass-200"
                >
                  <Bot className="h-3.5 w-3.5" />
                  Rakip yok mu? Bilgisayara karşı oyna
                  <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
                </button>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-2.5">
              {[
                { value: "6", label: "Haneli kod" },
                { value: "P2P", label: "Doğrudan bağlantı" },
                { value: "∞", label: "Sınırsız oyun" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-xl border border-line/60 bg-ink-900/45 px-3 py-2.5 text-center"
                >
                  <p className="font-display text-[17px] leading-none font-semibold text-brass-200">
                    {stat.value}
                  </p>
                  <p className="mt-1 text-[9.5px] font-semibold tracking-wider text-muted uppercase">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="animate-fade-up [animation-delay:200ms] lg:col-start-1 lg:row-start-2 lg:self-start">
            <ul className="grid max-w-[520px] gap-3 sm:grid-cols-2">
              {[
                { icon: ShieldCheck, text: "Tam satranç kuralları" },
                { icon: Zap, text: "Anlık hamle senkronu" },
                { icon: MessageSquare, text: "Oyun içi sohbet" },
                { icon: Users, text: "Kurulum gerekmez" },
              ].map(({ icon: Icon, text }) => (
                <li key={text} className="flex items-center gap-2.5 text-[13px] font-medium text-cream-dim">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md border border-line/80 bg-ink-800/70">
                    <Icon className="h-3.5 w-3.5 text-brass-300" strokeWidth={1.9} />
                  </span>
                  {text}
                </li>
              ))}
            </ul>

            <div className="mt-8 flex flex-wrap items-center gap-x-7 gap-y-3 border-t border-line/60 pt-6">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {["EY", "KE", "DE"].map((initials, index) => (
                    <span
                      key={initials}
                      className={cn(
                        "grid h-7 w-7 place-items-center rounded-full border-2 border-ink-950 text-[8.5px] font-bold",
                        index === 0 && "bg-[#3a4c3d] text-cream",
                        index === 1 && "bg-[#5c4a32] text-cream",
                        index === 2 && "bg-[#2c3a31] text-cream-dim"
                      )}
                    >
                      {initials}
                    </span>
                  ))}
                </div>
                <span className="text-[11.5px] text-muted">
                  <span className="font-bold text-cream-dim">2 oyuncu</span> · tek masa
                </span>
              </div>
              <div className="hidden h-4 w-px bg-line sm:block" />
              <p className="flex items-center gap-2 text-[11.5px] text-muted">
                <ShieldCheck className="h-3.5 w-3.5 text-sage-400" />
                PeerJS / WebRTC ile doğrudan bağlantı
              </p>
            </div>
          </div>
        </section>

        <section className="pb-16 lg:pb-20">
          <div className="grid items-end gap-10 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="eyebrow mb-3">Masanın arkasında</p>
              <h2 className="font-display text-[30px] leading-[1.12] font-medium text-cream sm:text-[36px]">
                Sıfır kurulum, <span className="text-brass-200 italic">eksiksiz</span> bir satranç
                deneyimi.
              </h2>
              <p className="mt-4 max-w-[400px] text-[13.5px] leading-relaxed text-muted">
                Roktan geçerken almaya, piyon terfisinden şah mata kadar tüm kurallar hazır.
                Hamleler seçtiğin renk doğrultusunda, yalnızca sıran geldiğinde yapılabilir.
              </p>
            </div>
            <MiniBoardPreview />
          </div>

          <div id="ozellikler" className="mt-10 grid gap-3.5 sm:grid-cols-3">
            {[
              {
                icon: KeyRound,
                title: "Tek kodla eşleşme",
                text: "Oda kur, 6 haneli kodu paylaş. Arkadaşın kodla katıldığında oyun otomatik başlar.",
              },
              {
                icon: ShieldCheck,
                title: "Kusursuz kural motoru",
                text: "chess.js altyapısıyla şah, mat, pat, rok, terfi ve geçerken alma kontrol edilir.",
              },
              {
                icon: MessageSquare,
                title: "Hamleler & sohbet",
                text: "Tüm hamle geçmişi, alınan taşlar ve oyun içi mesajlar aynı masada, anlık olarak.",
              },
            ].map(({ icon: Icon, title, text }) => (
              <article
                key={title}
                className="group rounded-2xl border border-line/70 bg-ink-900/40 p-5 transition-colors hover:border-brass-300/25 hover:bg-ink-850/70"
              >
                <span className="mb-4 grid h-9 w-9 place-items-center rounded-lg border border-brass-300/20 bg-brass-300/[0.07]">
                  <Icon className="h-[17px] w-[17px] text-brass-200" strokeWidth={1.9} />
                </span>
                <h3 className="text-[14px] font-bold text-cream">{title}</h3>
                <p className="mt-1.5 text-[12px] leading-relaxed text-muted">{text}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="nasil" className="scroll-mt-24 pb-16">
          <div className="rounded-3xl border border-line/70 bg-gradient-to-br from-ink-850/90 to-ink-950/60 p-6 sm:p-9">
            <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="eyebrow mb-2">Nasıl oynanır?</p>
                <h2 className="font-display text-[26px] font-medium text-cream sm:text-[30px]">
                  Üç adımda tahtaya.
                </h2>
              </div>
              <span className="text-[11px] text-muted">Ortalama süre: 20 saniye</span>
            </div>
            <div className="grid gap-5 sm:grid-cols-3">
              {[
                {
                  step: "01",
                  title: "Odayı kur",
                  text: "Adını yaz ve “Oda Kur”a bas. Beyaz taşlarla sen başlarsın.",
                },
                {
                  step: "02",
                  title: "Kodu paylaş",
                  text: "Oluşan 6 haneli kodu arkadaşına gönder. Katılan siyah taşları alır.",
                },
                {
                  step: "03",
                  title: "İlk hamleyi yap",
                  text: "İki taraf bağlanınca oyun başlar. Taşlarına dokun ve oyna.",
                },
              ].map((item, index) => (
                <div key={item.step} className="relative">
                  <div className="mb-3 flex items-center gap-3">
                    <span className="font-display text-[13px] font-semibold text-brass-300">
                      {item.step}
                    </span>
                    <span className="h-px flex-1 bg-line" />
                    {index === 2 && <Swords className="h-3.5 w-3.5 text-brass-300" />}
                  </div>
                  <h3 className="text-[13.5px] font-bold text-cream">{item.title}</h3>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-muted">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer id="kurallar" className="relative z-10 border-t border-line/60">
        <div className="mx-auto flex w-full max-w-[1240px] flex-col gap-5 px-5 py-7 sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <div className="flex items-center gap-3">
            <Logo size="sm" subtitle={false} />
            <span className="h-4 w-px bg-line" />
            <p className="text-[11px] text-muted">İki kişilik online satranç · tarayıcıda.</p>
          </div>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] text-muted">
            <span className="flex items-center gap-1.5">
              <Check className="h-3 w-3 text-live" /> FIDE kuralları
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="h-3 w-3 text-live" /> PeerJS (WebRTC)
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="h-3 w-3 text-live" /> Veri toplamaz
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
