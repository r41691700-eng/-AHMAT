import { useEffect, useMemo, useRef, useState } from "react";
import type { Color } from "chess.js";
import {
  ArrowRight,
  Bot,
  Check,
  Copy,
  Flag,
  Handshake,
  History,
  Link2,
  LogOut,
  MessageSquare,
  RotateCcw,
  Trophy,
  Users,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
} from "lucide-react";
import { ChessBoard, type BoardMove } from "@/components/ChessBoard";
import { ChatPanel } from "@/components/game/ChatPanel";
import { MoveList } from "@/components/game/MoveList";
import { PlayerBar } from "@/components/game/PlayerBar";
import { WaitingOverlay } from "@/components/game/WaitingOverlay";
import { Logo, Modal, StatusDot, ToastStack } from "@/components/ui";
import { usePeerGame } from "@/hooks/usePeerGame";
import { useToasts } from "@/hooks/useToasts";
import { findBestMove } from "@/lib/ai";
import {
  buildGame,
  colorName,
  detectOpening,
  getCaptures,
  getResult,
  materialScore,
  opposite,
  shareLinkForRoom,
  verboseMoves,
} from "@/lib/chess";
import type { ChatEntry, NetMessage } from "@/lib/protocol";
import type { Session } from "@/lib/session";
import { playSound } from "@/lib/sound";
import { cn } from "@/utils/cn";

type Props = {
  session: Session;
  onExit: () => void;
  onSwitchAI: () => void;
};

const EMPTY_CAPTURES = { byWhite: [], byBlack: [] };

export function GameRoom({ session, onExit, onSwitchAI }: Props) {
  const isOnline = session.mode === "online";
  const myColor: Color = session.role === "guest" ? "b" : "w";
  const opponentColor = opposite(myColor);

  const [history, setHistory] = useState<string[]>([]);
  const [opponentName, setOpponentName] = useState(
    isOnline ? (session.role === "host" ? "Rakip" : "Oda sahibi") : "Bilgisayar"
  );
  const [started, setStarted] = useState(!isOnline);
  const [resignWinner, setResignWinner] = useState<Color | null>(null);
  const [agreedDraw, setAgreedDraw] = useState(false);
  const [incomingDraw, setIncomingDraw] = useState(false);
  const [sentDraw, setSentDraw] = useState(false);
  const [incomingRematch, setIncomingRematch] = useState(false);
  const [sentRematch, setSentRematch] = useState(false);
  const [resultDismissed, setResultDismissed] = useState(false);
  const [forfeitOpen, setForfeitOpen] = useState(false);
  const [leaveOpen, setLeaveOpen] = useState(false);
  const [tab, setTab] = useState<"moves" | "chat">("moves");
  const [draft, setDraft] = useState("");
  const [chat, setChat] = useState<ChatEntry[]>(() => [
    {
      id: "boot",
      author: "system",
      name: "Sistem",
      text: isOnline
        ? session.role === "host"
          ? "Oda oluşturuldu. Rakip bekleniyor…"
          : "Odaya bağlanılıyor…"
        : "Bilgisayar rakibin hazır. İyi oyunlar!",
      time: Date.now(),
    },
  ]);
  const [unread, setUnread] = useState(0);
  const [soundOn, setSoundOn] = useState(() => {
    if (typeof window === "undefined") return true;
    return localStorage.getItem("kare:sound") !== "off";
  });
  const [flipped, setFlipped] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [copied, setCopied] = useState(false);

  const { toasts, push, dismiss } = useToasts();
  const sendRef = useRef<(message: NetMessage) => boolean>(() => false);
  const historyRef = useRef<string[]>([]);
  const blockedAt = useRef(0);
  const announced = useRef("");
  const joined = useRef(false);

  const peer = usePeerGame({
    roomCode: session.roomCode,
    role: session.role === "guest" ? "guest" : "host",
    name: session.name,
    enabled: isOnline && session.role !== "ai",
    onMessage: (message) => handleIncoming(message),
    onOpen: (remoteName) => handlePeerOpen(remoteName),
    onClose: () => handlePeerClose(),
  });

  useEffect(() => {
    sendRef.current = peer.send;
  }, [peer.send]);

  // The joiner introduces itself with a few retries: the data channel can open
  // a tick before the host has attached its listeners.
  useEffect(() => {
    if (!isOnline || session.role !== "guest" || peer.phase !== "connected" || started) return;
    const timers = [0, 500, 1300, 2500, 4200, 6500].map((delay) =>
      setTimeout(() => sendRef.current({ t: "hello", name: session.name }), delay)
    );
    return () => timers.forEach(clearTimeout);
  }, [isOnline, session.role, session.name, peer.phase, started]);

  // Retry the name exchange until both sides know each other.
  useEffect(() => {
    if (!isOnline || !started || peer.phase !== "connected") return;
    if (opponentName !== "Rakip" && opponentName !== "Oda sahibi") return;
    const greet = () =>
      sendRef.current(
        session.role === "host"
          ? { t: "welcome", name: session.name, history: historyRef.current }
          : { t: "hello", name: session.name }
      );
    greet();
    const timers = [900, 2200, 4000].map((delay) => setTimeout(greet, delay));
    return () => timers.forEach(clearTimeout);
  }, [isOnline, started, peer.phase, opponentName, session.name, session.role]);

  useEffect(() => {
    historyRef.current = history;
  }, [history]);

  const game = useMemo(() => buildGame(history), [history]);
  const moves = useMemo(() => verboseMoves(history), [history]);
  const result = useMemo(() => getResult(game, resignWinner, agreedDraw), [game, resignWinner, agreedDraw]);
  const captures = useMemo(() => {
    if (history.length === 0) return EMPTY_CAPTURES;
    return getCaptures(history);
  }, [history]);
  const myCaptures = myColor === "w" ? captures.byWhite : captures.byBlack;
  const theirCaptures = myColor === "w" ? captures.byBlack : captures.byWhite;
  const advantage = materialScore(captures);
  const myAdvantage = myColor === "w" ? advantage : -advantage;
  const opening = detectOpening(history);
  const myTurn = game.turn() === myColor;
  const orientation: Color = flipped ? opponentColor : myColor;
  const opponentConnected = isOnline ? peer.phase === "connected" : true;
  const waiting = isOnline && !started && peer.phase !== "error";
  const overlayState: "waiting" | "connecting" | "error" =
    peer.phase === "error" || peer.phase === "disconnected"
      ? "error"
      : session.role === "host" && peer.phase === "waiting"
        ? "waiting"
        : "connecting";
  const canPlay =
    !result.over &&
    myTurn &&
    (isOnline ? started && peer.phase === "connected" : true);

  const showResult = result.over && !resultDismissed;
  const check = game.isCheck() && !game.isGameOver();

  const headline = result.over
    ? result.winner
      ? `${colorName(result.winner)} kazandı`
      : "Berabere"
    : check
      ? "Şah!"
      : !isOnline
      ? thinking
        ? "Bilgisayar düşünüyor"
        : myTurn
          ? "Sıra sende"
          : "Rakip oynuyor"
      : peer.phase === "disconnected"
        ? "Bağlantı koptu"
        : waiting
          ? "Rakip bekleniyor"
          : myTurn
            ? "Sıra sende"
            : "Sıra rakipte";

  const detail = result.over
    ? result.detail
    : !isOnline
      ? check
        ? "Şah! Şahını güvenli bir kareye taşı."
        : myTurn
          ? "Bir taşına dokun, yeşil noktalara hamle yap."
          : "Bilgisayar en iyi hamleyi arıyor."
      : peer.phase === "disconnected"
        ? "Rakip masadan ayrıldı. Tahtayı inceleyebilirsin."
        : waiting
          ? "Rakip odaya katıldığında oyun otomatik başlar."
          : check
            ? "Şah! Şahını korumalısın."
            : myTurn
              ? "Hamle sırası sende. Tahtaya dokun."
              : "Rakibin hamlesini bekliyorsun.";

  function addSystem(text: string) {
    setChat((current) => [
      ...current,
      {
        id: `sys-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        author: "system",
        name: "Sistem",
        text,
        time: Date.now(),
      },
    ]);
  }

  function handlePeerOpen(remoteName?: string) {
    if (session.role === "guest") {
      sendRef.current({ t: "hello", name: session.name });
      return;
    }
    const name = remoteName?.trim();
    if (name) setOpponentName(name);
    // Host is authoritative: greet right away so a fast joiner cannot miss state.
    sendRef.current({ t: "welcome", name: session.name, history });
    setStarted(true);
  }

  function handlePeerClose() {
    addSystem("Rakip bağlantısı kesildi.");
    push("Rakip ayrıldı", {
      description: "Bağlantı koptu. Tahtayı inceleyebilir veya yeni bir oda kurabilirsin.",
      tone: "red",
      duration: 6000,
    });
    playSound("notify", soundOn);
  }

  function handleIncoming(message: NetMessage) {
    switch (message.t) {
      case "hello": {
        setOpponentName(message.name || "Rakip");
        setStarted(true);
        if (session.role === "host") {
          sendRef.current({ t: "welcome", name: session.name, history });
        }
        if (joined.current) break;
        joined.current = true;
        addSystem(`${message.name || "Rakip"} odaya katıldı. Oyun başladı!`);
        push("Oyun başladı!", {
          description: `${message.name || "Rakip"} siyah taşlarla oynuyor. Sıra beyazda.`,
          tone: "green",
          duration: 5000,
        });
        playSound("join", soundOn);
        break;
      }
      case "welcome": {
        setOpponentName(message.name || "Oda sahibi");
        setStarted(true);
        if (Array.isArray(message.history) && message.history.length > history.length) {
          setHistory(message.history);
        }
        if (joined.current) break;
        joined.current = true;
        addSystem(`Odaya katıldın. Rakibin: ${message.name || "Oda sahibi"}. Oyun başladı!`);
        push("Oyun başladı!", {
          description: `${message.name || "Oda sahibi"} beyaz taşlarla oynuyor.`,
          tone: "green",
          duration: 5000,
        });
        playSound("join", soundOn);
        break;
      }
      case "move": {
        if (!Array.isArray(message.history)) return;
        if (message.history.length < history.length) {
          sendRef.current({ t: "resync", history });
          return;
        }
        const nextGame = buildGame(message.history);
        const applied = nextGame.history();
        // Reject malformed histories rather than desynchronising the board.
        if (applied.length !== message.history.length) return;
        if (message.history.length === history.length) {
          if (applied.join() !== history.join()) sendRef.current({ t: "resync", history });
          return;
        }
        const nextMoves = nextGame.history({ verbose: true });
        const last = nextMoves[nextMoves.length - 1];
        setHistory(message.history);
        setResultDismissed(false);
        if (last) {
          const sound = nextGame.isCheckmate()
            ? "lose"
            : nextGame.isCheck()
              ? "check"
              : last.captured
                ? "capture"
                : "move";
          playSound(sound, soundOn);
        }
        break;
      }
      case "chat": {
        if (typeof message.text !== "string" || !message.text.trim()) return;
        setChat((current) => [
          ...current,
          {
            id: message.id || `chat-${Date.now()}`,
            author: "opponent",
            name: message.name || opponentName,
            color: message.color,
            text: message.text.slice(0, 180),
            time: Date.now(),
          },
        ]);
        setUnread((count) => (tab === "chat" ? 0 : count + 1));
        playSound("notify", soundOn);
        break;
      }
      case "draw-offer": {
        setIncomingDraw(true);
        push("Beraberlik teklifi", {
          description: "Rakibin oyunu berabere bitirmek istiyor.",
          tone: "gold",
          duration: 6000,
        });
        playSound("notify", soundOn);
        break;
      }
      case "draw-accept": {
        setAgreedDraw(true);
        setSentDraw(false);
        setIncomingDraw(false);
        addSystem("Beraberlik üzerinde anlaşıldı.");
        push("Beraberlik kabul edildi", { tone: "green" });
        break;
      }
      case "draw-decline": {
        setSentDraw(false);
        push("Beraberlik teklifi reddedildi", { tone: "neutral" });
        break;
      }
      case "resign": {
        setResignWinner(myColor);
        addSystem(`${opponentName} maçtan çekildi.`);
        push("Rakip çekildi", { description: "Maçı kazandın!", tone: "green" });
        break;
      }
      case "rematch-offer": {
        setIncomingRematch(true);
        setResultDismissed(true);
        addSystem("Rakip yeni bir oyun istiyor.");
        push("Yeni oyun teklifi", {
          description: "Rakibin rövanş istiyor.",
          tone: "gold",
          duration: 6000,
        });
        playSound("notify", soundOn);
        break;
      }
      case "rematch-accept": {
        setIncomingRematch(false);
        setSentRematch(false);
        resetBoard();
        break;
      }
      case "rematch-decline": {
        setSentRematch(false);
        push("Yeni oyun teklifi reddedildi", { tone: "neutral" });
        break;
      }
      case "resync": {
        if (Array.isArray(message.history) && message.history.length >= history.length) {
          setHistory(message.history);
        } else {
          sendRef.current({ t: "resync", history });
        }
        break;
      }
      case "ping":
      default:
        break;
    }
  }

  function resetBoard(announce = true) {
    setHistory([]);
    setResignWinner(null);
    setAgreedDraw(false);
    setIncomingDraw(false);
    setSentDraw(false);
    setIncomingRematch(false);
    setSentRematch(false);
    setResultDismissed(false);
    setThinking(false);
    setTab("moves");
    if (announce) addSystem("Yeni oyun başladı. Tahta temiz, beyaz oynar.");
  }

  function handleMove(move: BoardMove) {
    if (result.over) {
      block("over");
      return;
    }
    if (!myTurn) {
      block("turn");
      return;
    }
    if (isOnline && (!started || peer.phase !== "connected")) {
      block("waiting");
      return;
    }

    const nextGame = buildGame(history);
    let made;
    try {
      made = nextGame.move({
        from: move.from,
        to: move.to,
        promotion: move.promotion ?? "q",
      });
    } catch {
      return;
    }
    if (!made) return;

    const nextHistory = [...history, made.san];
    setHistory(nextHistory);
    setResultDismissed(false);
    if (isOnline) sendRef.current({ t: "move", history: nextHistory });

    if (nextGame.isCheckmate()) return;
    if (nextGame.isCheck()) playSound("check", soundOn);
    else if (made.captured) playSound("capture", soundOn);
    else playSound("move", soundOn);
  }

  function block(reason: "turn" | "waiting" | "over") {
    const now = Date.now();
    if (now - blockedAt.current < 1600) return;
    blockedAt.current = now;
    if (reason === "turn") {
      push("Sıra rakipte", { description: "Rakibinin hamlesini beklemelisin.", tone: "neutral" });
    } else if (reason === "waiting") {
      push("Rakip bekleniyor", { description: "Rakip katıldığında taşlarını oynayabilirsin.", tone: "gold" });
    } else {
      push("Oyun sona erdi", { description: "Yeni bir oyun başlatabilirsin.", tone: "neutral" });
    }
  }

  function handleChatSend(text: string) {
    const clean = text.trim().slice(0, 180);
    if (!clean) return;
    setChat((current) => [
      ...current,
      {
        id: `me-${Date.now()}`,
        author: "me",
        name: session.name,
        text: clean,
        time: Date.now(),
      },
    ]);
    setDraft("");
    if (isOnline && peer.phase === "connected") {
      sendRef.current({
        t: "chat",
        id: `msg-${Date.now()}`,
        name: session.name,
        color: myColor,
        text: clean,
      });
    }
  }

  function offerDraw() {
    if (result.over) return;
    if (!isOnline) {
      push("Bilgisayar beraberliği kabul etmiyor", {
        description: "Şah mat için oynamaya devam et!",
        tone: "neutral",
      });
      return;
    }
    if (peer.phase !== "connected" || sentDraw) return;
    sendRef.current({ t: "draw-offer" });
    setSentDraw(true);
    addSystem("Beraberlik teklif ettin. Rakibin yanıtı bekleniyor…");
    push("Teklif gönderildi", { description: "Rakibinin yanıtı bekleniyor.", tone: "gold" });
  }

  function acceptDraw() {
    setIncomingDraw(false);
    setAgreedDraw(true);
    setSentDraw(false);
    if (isOnline) sendRef.current({ t: "draw-accept" });
    addSystem("Beraberlik üzerinde anlaşıldı.");
    push("Beraberlik", { description: "İki taraf da teklifi kabul etti.", tone: "green" });
  }

  function declineDraw() {
    setIncomingDraw(false);
    if (isOnline) sendRef.current({ t: "draw-decline" });
    push("Teklif reddedildi", { tone: "neutral" });
  }

  function confirmForfeit() {
    setForfeitOpen(false);
    if (result.over) return;
    if (isOnline) {
      sendRef.current({ t: "resign" });
      addSystem(`${session.name} maçtan çekildi.`);
    }
    setResignWinner(opponentColor);
    setResultDismissed(false);
    playSound("lose", soundOn);
  }

  function requestRematch() {
    if (!isOnline) {
      resetBoard();
      return;
    }
    if (sentRematch) return;
    if (peer.phase !== "connected") {
      push("Bağlantı yok", { description: "Rakibin ayrıldığı için yeni oyun isteyemiyorsun.", tone: "red" });
      return;
    }
    sendRef.current({ t: "rematch-offer" });
    setSentRematch(true);
    addSystem("Yeni oyun teklifi gönderildi.");
    push("Teklif gönderildi", { description: "Rakibinin rövanş yanıtı bekleniyor.", tone: "gold" });
  }

  function acceptRematch() {
    setIncomingRematch(false);
    setSentRematch(false);
    if (isOnline) sendRef.current({ t: "rematch-accept" });
    resetBoard();
  }

  function declineRematch() {
    setIncomingRematch(false);
    if (isOnline) sendRef.current({ t: "rematch-decline" });
  }

  async function copyText(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        const area = document.createElement("textarea");
        area.value = text;
        area.style.position = "fixed";
        area.style.opacity = "0";
        document.body.appendChild(area);
        area.select();
        const ok = document.execCommand("copy");
        area.remove();
        return ok;
      } catch {
        return false;
      }
    }
  }

  async function copyLink() {
    const ok = await copyText(shareLinkForRoom(session.roomCode));
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
      push("Davet bağlantısı kopyalandı", {
        description: "Arkadaşına gönder, tek tıkla odaya katılsın.",
        tone: "green",
      });
    } else {
      push("Kopyalanamadı", { description: `Oda kodunu paylaş: ${session.roomCode}`, tone: "red" });
    }
    return ok;
  }

  async function copyCode() {
    const ok = await copyText(session.roomCode);
    if (ok) push("Oda kodu kopyalandı", { description: session.roomCode, tone: "green" });
    return ok;
  }

  // Computer opponent
  useEffect(() => {
    if (isOnline || result.over) return;
    if (game.turn() !== "b") return;

    setThinking(true);
    const timer = setTimeout(
      () => {
        const best = findBestMove(history, 2);
        setThinking(false);
        if (!best) return;
        const nextGame = buildGame(history);
        let made;
        try {
          made = nextGame.move({ from: best.from, to: best.to, promotion: best.promotion ?? "q" });
        } catch {
          return;
        }
        if (!made) return;
        setHistory((current) => [...current, made!.san]);
        if (nextGame.isCheckmate()) return;
        if (nextGame.isCheck()) playSound("check", soundOn);
        else if (made.captured) playSound("capture", soundOn);
        else playSound("move", soundOn);
      },
      480 + Math.random() * 620
    );

    return () => {
      clearTimeout(timer);
      setThinking(false);
    };
  }, [isOnline, result.over, game, history, soundOn]);

  // Announce the result exactly once per finished game.
  useEffect(() => {
    if (!result.over) {
      announced.current = "";
      return;
    }
    const key = `${history.length}-${result.kind}-${result.winner ?? "draw"}`;
    if (announced.current === key) return;
    announced.current = key;
    if (result.kind === "checkmate" || result.kind === "draw") {
      addSystem(`${result.title}. ${result.detail}`);
    }
    setResultDismissed(false);
    playSound(
      result.winner === null ? "notify" : result.winner === myColor ? "win" : "lose",
      soundOn
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [result.over, result.kind, result.winner, history.length, myColor, soundOn]);

  useEffect(() => {
    try {
      localStorage.setItem("kare:sound", soundOn ? "on" : "off");
    } catch {
      /* ignore */
    }
  }, [soundOn]);

  useEffect(() => {
    if (tab === "chat") setUnread(0);
  }, [tab]);

  const outcome =
    result.winner === null ? "Berabere" : result.winner === myColor ? "Kazandın!" : "Kaybettin";

  return (
    <div className="relative flex min-h-screen flex-col">
      <ToastStack toasts={toasts} dismiss={dismiss} />

      <header className="sticky top-0 z-40 border-b border-line/60 bg-ink-950/85 backdrop-blur-xl">
        <div className="mx-auto flex h-[68px] w-full max-w-[1440px] items-center justify-between gap-2 px-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-3 sm:gap-4">
            <Logo onClick={() => setLeaveOpen(true)} size="sm" subtitle={false} />
            <span className="hidden h-5 w-px bg-line sm:block" />
            {isOnline ? (
              <button
                type="button"
                onClick={copyCode}
                className="group flex items-center gap-2.5 rounded-lg border border-line/70 bg-ink-900/60 px-2.5 py-1.5 transition hover:border-brass-300/30"
                title="Oda kodunu kopyala"
              >
                <div className="text-left">
                  <p className="text-[8px] font-bold tracking-[0.18em] text-muted/80 uppercase">
                    Oda kodu
                  </p>
                  <p className="code-chip text-[11.5px] leading-tight font-bold text-brass-200 sm:text-[13px]">
                    #{session.roomCode}
                  </p>
                </div>
                {copied ? (
                  <Check className="h-3.5 w-3.5 text-live" />
                ) : (
                  <Copy className="h-3.5 w-3.5 text-muted transition group-hover:text-brass-200" />
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 rounded-lg border border-line/70 bg-ink-900/60 px-2.5 py-1.5">
                <Bot className="h-3.5 w-3.5 text-brass-200" />
                <div>
                  <p className="text-[8px] font-bold tracking-[0.18em] text-muted/80 uppercase">
                    Hızlı oyun
                  </p>
                  <p className="text-[11px] leading-tight font-bold text-cream">Bilgisayar · Siyah</p>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2.5">
            <span className="hidden items-center gap-2 rounded-full border border-line/70 bg-ink-900/60 px-3 py-1.5 text-[10px] font-bold tracking-wider text-muted uppercase sm:inline-flex">
              <StatusDot
                state={
                  !isOnline
                    ? "online"
                    : peer.phase === "connected"
                      ? "online"
                      : peer.phase === "error" || peer.phase === "disconnected"
                        ? "error"
                        : "waiting"
                }
              />
              {!isOnline
                ? "Tek cihaz"
                : peer.phase === "connected"
                  ? "Bağlı"
                  : peer.phase === "error"
                    ? "Hata"
                    : peer.phase === "disconnected"
                      ? "Kesildi"
                      : peer.phase === "waiting"
                        ? "Oda açık"
                        : "Bağlanıyor"}
            </span>
            <button
              type="button"
              onClick={() => setSoundOn((value) => !value)}
              aria-label={soundOn ? "Sesi kapat" : "Sesi aç"}
              className="grid h-9 w-9 place-items-center rounded-lg border border-line/70 bg-ink-900/60 text-muted transition hover:border-brass-300/30 hover:text-cream"
            >
              {soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={() => setLeaveOpen(true)}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-line/70 bg-ink-900/60 px-2.5 text-[11.5px] font-semibold text-muted transition hover:border-red-400/30 hover:text-red-300"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Ayrıl</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid w-full max-w-[1440px] flex-1 gap-4 px-3 py-4 sm:px-6 sm:py-5 xl:grid-cols-[minmax(0,1fr)_370px] xl:gap-6">
        {/* Board column */}
        <section className="flex flex-col gap-2.5">
          {isOnline && started && peer.phase === "disconnected" && (
            <div className="flex flex-wrap items-center gap-2 rounded-xl border border-red-400/25 bg-red-400/[0.07] px-3 py-2">
              <WifiOff className="h-3.5 w-3.5 text-red-300" />
              <p className="flex-1 text-[11.5px] font-medium text-red-200/90">
                Rakip masadan ayrıldı. Bağlantı koptu.
              </p>
              <button
                type="button"
                onClick={onExit}
                className="rounded-md border border-red-400/25 px-2 py-1 text-[10px] font-bold text-red-200 uppercase transition hover:bg-red-400/10"
              >
                Yeni oda
              </button>
            </div>
          )}

          <div className="mx-auto w-full max-w-[640px]">
            <PlayerBar
              name={opponentName}
              color={opponentColor}
              isMe={false}
              isTurn={!result.over && game.turn() === opponentColor}
              captured={theirCaptures}
              advantage={-myAdvantage}
              connected={opponentConnected}
              roleLabel={isOnline ? (session.role === "host" ? "Konuk" : "Oda sahibi") : "Yapay zekâ"}
              isBot={!isOnline}
              thinking={!isOnline && thinking && game.turn() === "b"}
              gameOver={result.over}
            />
          </div>

          <div className="relative mx-auto w-full max-w-[640px]">
            <ChessBoard
              history={history}
              myColor={myColor}
              orientation={orientation}
              interactive={canPlay}
              onMove={handleMove}
              onBlocked={block}
            />
            {isOnline && !started && (
              <WaitingOverlay
                code={session.roomCode}
                role={session.role === "guest" ? "guest" : "host"}
                state={overlayState}
                error={
                  peer.error ??
                  (peer.phase === "disconnected"
                    ? "Bağlantı kesildi. Yeniden deneyebilirsin."
                    : null)
                }
                onCopyLink={copyLink}
                onCopyCode={copyCode}
                onRetry={peer.retry}
                onPlayAI={onSwitchAI}
              />
            )}
          </div>

          <div className="mx-auto w-full max-w-[640px]">
            <PlayerBar
              name={session.name}
              color={myColor}
              isMe
              isTurn={!result.over && myTurn}
              captured={myCaptures}
              advantage={myAdvantage}
              connected
              roleLabel={isOnline ? (session.role === "host" ? "Oda sahibi" : "Konuk") : session.role === "ai" ? "Sen" : "Oyuncu"}
              gameOver={result.over}
            />
          </div>

          <div className="mx-auto flex w-full max-w-[640px] flex-wrap items-center justify-between gap-2 px-1">
            <div className="flex items-center gap-2 text-[10.5px] font-medium text-muted">
              {isOnline ? (
                peer.phase === "connected" ? (
                  <Wifi className="h-3.5 w-3.5 text-live" />
                ) : (
                  <WifiOff className="h-3.5 w-3.5 text-muted/70" />
                )
              ) : (
                <Bot className="h-3.5 w-3.5 text-brass-300" />
              )}
              <span>
                {isOnline
                  ? peer.phase === "connected"
                    ? "Uçtan uca WebRTC bağlantısı aktif"
                    : "Bağlantı kuruluyor…"
                  : "Tek cihaz modu · hamleler anında"}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setFlipped((value) => !value)}
              className="inline-flex items-center gap-1.5 rounded-md border border-line/60 bg-ink-900/50 px-2 py-1 text-[10px] font-semibold text-muted transition hover:text-cream"
            >
              <RotateCcw className="h-3 w-3" />
              Tahtayı çevir
            </button>
          </div>
        </section>

        {/* Sidebar */}
        <aside className="flex flex-col gap-3">
          <div className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <p className="eyebrow">Maç durumu</p>
              <span className="flex items-center gap-1.5 text-[9.5px] font-bold tracking-wider uppercase">
                <StatusDot state={result.over ? "offline" : opponentConnected ? "online" : "waiting"} />
                <span className={cn("", result.over ? "text-muted" : opponentConnected ? "text-live" : "text-brass-200")}>
                  {result.over ? "Tamamlandı" : opponentConnected ? "Canlı" : "Bekliyor"}
                </span>
              </span>
            </div>
            <div className="mt-2.5 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h1 className="font-display text-[23px] leading-tight font-semibold text-cream">
                  {headline}
                </h1>
                <p className="mt-1 text-[11px] leading-relaxed text-muted">{detail}</p>
              </div>
              <span
                className={cn(
                  "grid h-10 w-10 shrink-0 place-items-center rounded-xl border text-[20px]",
                  result.over && result.winner
                    ? "border-brass-300/30 bg-brass-300/10"
                    : "border-line/80 bg-ink-800"
                )}
              >
                {result.over ? (
                  result.winner ? (
                    <Trophy className="h-4 w-4 text-brass-200" />
                  ) : (
                    <Handshake className="h-4 w-4 text-brass-200" />
                  )
                ) : (
                  <span className={game.turn() === "w" ? "piece-mini-w" : "piece-mini-b"}>♟</span>
                )}
              </span>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-1.5">
              {[
                { label: "Sıra", value: result.over ? "—" : colorName(game.turn()) },
                { label: "Hamle", value: String(Math.ceil(history.length / 2)) },
                { label: "Açılış", value: opening },
              ].map((stat) => (
                <div key={stat.label} className="rounded-lg border border-line/50 bg-ink-950/40 px-2 py-1.5">
                  <p className="text-[8px] font-bold tracking-[0.12em] text-muted/70 uppercase">
                    {stat.label}
                  </p>
                  <p className="mt-0.5 truncate text-[10.5px] font-semibold text-cream-dim" title={stat.value}>
                    {stat.value}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass flex h-[318px] flex-col overflow-hidden rounded-2xl">
            <div className="flex shrink-0 border-b border-line/60">
              <button
                type="button"
                onClick={() => setTab("moves")}
                className={cn(
                  "flex flex-1 items-center justify-center gap-1.5 py-2.5 text-[11px] font-bold tracking-wide transition",
                  tab === "moves"
                    ? "border-b-2 border-brass-300 bg-brass-300/[0.06] text-cream"
                    : "border-b-2 border-transparent text-muted hover:text-cream-dim"
                )}
              >
                <History className="h-3.5 w-3.5" />
                Hamleler
                <span className="rounded bg-ink-700 px-1 text-[9px] text-muted">{history.length}</span>
              </button>
              <button
                type="button"
                onClick={() => setTab("chat")}
                className={cn(
                  "relative flex flex-1 items-center justify-center gap-1.5 py-2.5 text-[11px] font-bold tracking-wide transition",
                  tab === "chat"
                    ? "border-b-2 border-brass-300 bg-brass-300/[0.06] text-cream"
                    : "border-b-2 border-transparent text-muted hover:text-cream-dim"
                )}
              >
                <MessageSquare className="h-3.5 w-3.5" />
                Sohbet
                {unread > 0 && (
                  <span className="grid h-4 min-w-4 place-items-center rounded-full bg-brass-300 px-1 text-[8.5px] font-extrabold text-ink-950">
                    {unread}
                  </span>
                )}
              </button>
            </div>
            {tab === "moves" ? (
              <MoveList moves={moves} opening={opening} playerColor={myColor} />
            ) : (
              <ChatPanel
                messages={chat}
                me={session.name}
                onSend={handleChatSend}
                disabled={!isOnline}
                draft={draft}
                setDraft={setDraft}
              />
            )}
          </div>

          <div className="glass rounded-2xl p-3">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={offerDraw}
                disabled={!isOnline || result.over || sentDraw || !started}
                className="flex items-center justify-center gap-1.5 rounded-lg border border-line/70 bg-ink-800/70 px-2 py-2 text-[11px] font-semibold text-cream-dim transition hover:border-brass-300/30 hover:text-cream disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Handshake className="h-3.5 w-3.5 text-sage-300" />
                {sentDraw ? "Teklif gönderildi" : "Beraberlik"}
              </button>
              <button
                type="button"
                onClick={() => setForfeitOpen(true)}
                disabled={result.over || (isOnline && !started)}
                className="flex items-center justify-center gap-1.5 rounded-lg border border-line/70 bg-ink-800/70 px-2 py-2 text-[11px] font-semibold text-cream-dim transition hover:border-red-400/30 hover:text-red-300 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Flag className="h-3.5 w-3.5 text-red-300/80" />
                Terk et
              </button>
              {isOnline ? (
                <button
                  type="button"
                  onClick={copyLink}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-brass-300/25 bg-brass-300/[0.07] px-2 py-2 text-[11px] font-semibold text-brass-200 transition hover:bg-brass-300/[0.13]"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-live" /> : <Link2 className="h-3.5 w-3.5" />}
                  {copied ? "Kopyalandı" : "Davet et"}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => resetBoard()}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-brass-300/25 bg-brass-300/[0.07] px-2 py-2 text-[11px] font-semibold text-brass-200 transition hover:bg-brass-300/[0.13]"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Yeniden başlat
                </button>
              )}
              <button
                type="button"
                onClick={() => (result.over ? requestRematch() : undefined)}
                disabled={!result.over || (isOnline && sentRematch)}
                className="flex items-center justify-center gap-1.5 rounded-lg border border-line/70 bg-ink-800/70 px-2 py-2 text-[11px] font-semibold text-cream-dim transition hover:border-brass-300/30 hover:text-cream disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Users className="h-3.5 w-3.5 text-brass-300" />
                {sentRematch ? "Bekleniyor…" : "Yeni oyun"}
              </button>
            </div>
          </div>

          {isOnline ? (
            <div className="relative overflow-hidden rounded-2xl border border-brass-300/20 bg-gradient-to-br from-brass-300/[0.09] via-ink-900/50 to-ink-900/30 p-3.5">
              <div className="pointer-events-none absolute -top-8 -right-6 h-24 w-24 rounded-full bg-brass-300/10 blur-2xl" />
              <div className="relative flex items-center justify-between">
                <p className="text-[9px] font-bold tracking-[0.18em] text-brass-200/80 uppercase">
                  Arkadaşını davet et
                </p>
                <Users className="h-3.5 w-3.5 text-brass-200/70" />
              </div>
              <div className="relative mt-1.5 flex items-end justify-between gap-2">
                <div>
                  <p className="text-[8px] font-bold tracking-[0.16em] text-muted uppercase">Oda kodu</p>
                  <p className="code-chip font-display text-[22px] leading-none font-semibold text-cream">
                    #{session.roomCode}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={copyCode}
                  className="grid h-8 w-8 place-items-center rounded-lg border border-brass-300/25 bg-ink-950/40 text-brass-200 transition hover:bg-brass-300/15"
                  aria-label="Oda kodunu kopyala"
                >
                  <Copy className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="relative mt-2 text-[10px] leading-relaxed text-muted">
                Kodu paylaş veya davet bağlantısını gönder; arkadaşın katıldığında oyun başlar.
              </p>
            </div>
          ) : (
            <div className="rounded-2xl border border-line/70 bg-ink-900/45 p-3.5">
              <p className="text-[9px] font-bold tracking-[0.18em] text-brass-200/80 uppercase">
                İki kişilik oyna
              </p>
              <p className="mt-1.5 text-[10.5px] leading-relaxed text-muted">
                Bu maç bilgisayara karşı. Arkadaşınla oynamak için ana ekrandan bir oda kur,
                6 haneli kodu paylaş.
              </p>
              <button
                type="button"
                onClick={onExit}
                className="group mt-2 inline-flex items-center gap-1.5 text-[10.5px] font-bold text-brass-200 transition hover:text-brass-100"
              >
                Oda kur
                <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
              </button>
            </div>
          )}
        </aside>
      </main>

      <footer className="mx-auto flex w-full max-w-[1440px] flex-wrap items-center justify-between gap-2 border-t border-line/40 px-4 py-3 text-[9.5px] text-muted/60 sm:px-6">
        <p>chess.js kural motoru · PeerJS / WebRTC gerçek zamanlı bağlantı</p>
        <p className="code-chip">KARE · {isOnline ? `ODA #${session.roomCode}` : "TEK CİHAZ"}</p>
      </footer>

      {/* Draw offer */}
      <Modal
        open={incomingDraw && !result.over}
        onClose={declineDraw}
        eyebrow="Rakip teklifi"
        title="Beraberlik teklifi"
        width="max-w-sm"
      >
        <p className="text-[12.5px] leading-relaxed text-cream-dim">
          <span className="font-bold text-cream">{opponentName}</span> oyunu berabere bitirmek
          istiyor. Teklifi kabul ediyor musun?
        </p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button type="button" onClick={declineDraw} className="btn-ghost !py-2.5 !text-[12px]">
            Reddet
          </button>
          <button type="button" onClick={acceptDraw} className="btn-gold !py-2.5 !text-[12px]">
            <Handshake className="h-4 w-4" />
            Kabul et
          </button>
        </div>
      </Modal>

      {/* Rematch offer */}
      <Modal
        open={incomingRematch}
        onClose={declineRematch}
        eyebrow="Rövanş"
        title="Yeni oyun teklifi"
        width="max-w-sm"
      >
        <p className="text-[12.5px] leading-relaxed text-cream-dim">
          <span className="font-bold text-cream">{opponentName}</span> tahtayı sıfırlayıp yeniden
          oynamak istiyor. Renkler aynı kalacak.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button type="button" onClick={declineRematch} className="btn-ghost !py-2.5 !text-[12px]">
            Şimdi değil
          </button>
          <button type="button" onClick={acceptRematch} className="btn-gold !py-2.5 !text-[12px]">
            <RotateCcw className="h-4 w-4" />
            Kabul et
          </button>
        </div>
      </Modal>

      {/* Forfeit */}
      <Modal
        open={forfeitOpen}
        onClose={() => setForfeitOpen(false)}
        eyebrow="Dikkat"
        title="Maçtan çekilmek üzeresin"
        width="max-w-sm"
      >
        <p className="text-[12.5px] leading-relaxed text-cream-dim">
          {isOnline
            ? "Terk edersen rakibin maçı kazanır ve oyun sonlanır."
            : "Bilgisayar maçı kazanır. İstersen yeni bir oyun başlatabilirsin."}
        </p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button type="button" onClick={() => setForfeitOpen(false)} className="btn-ghost !py-2.5 !text-[12px]">
            Devam et
          </button>
          <button
            type="button"
            onClick={confirmForfeit}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-red-400/30 bg-red-400/10 px-4 py-2.5 text-[12px] font-bold text-red-200 transition hover:bg-red-400/15"
          >
            <Flag className="h-4 w-4" />
            Terk et
          </button>
        </div>
      </Modal>

      {/* Leave */}
      <Modal
        open={leaveOpen}
        onClose={() => setLeaveOpen(false)}
        eyebrow="Masadan ayrıl"
        title="Oyundan ayrılmak istiyor musun?"
        width="max-w-sm"
      >
        <p className="text-[12.5px] leading-relaxed text-cream-dim">
          {isOnline
            ? "Oda kapanacak ve rakibinle bağlantın kesilecek. Maç devam etmez."
            : "Bu oyundan ayrılacak ve ana ekrana döneceksin."}
        </p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button type="button" onClick={() => setLeaveOpen(false)} className="btn-ghost !py-2.5 !text-[12px]">
            Masada kal
          </button>
          <button
            type="button"
            onClick={onExit}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-red-400/30 bg-red-400/10 px-4 py-2.5 text-[12px] font-bold text-red-200 transition hover:bg-red-400/15"
          >
            <LogOut className="h-4 w-4" />
            Ayrıl
          </button>
        </div>
      </Modal>

      {/* Result */}
      <Modal
        open={showResult}
        onClose={() => setResultDismissed(true)}
        eyebrow="Maç sonucu"
        title={result.title}
        width="max-w-md"
      >
        <div className="text-center">
          <div
            className={cn(
              "mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl border",
              result.winner === myColor
                ? "border-brass-300/30 bg-brass-300/10"
                : result.winner === null
                  ? "border-line bg-ink-800"
                  : "border-line bg-ink-800/70"
            )}
          >
            {result.winner ? (
              <Trophy className="h-7 w-7 text-brass-200" />
            ) : (
              <Handshake className="h-7 w-7 text-brass-200" />
            )}
          </div>
          <p className="eyebrow mb-1">{result.kind === "checkmate" ? "Şah mat" : "Oyun bitti"}</p>
          <h3 className="font-display text-[30px] leading-tight font-semibold text-cream">
            {outcome}
          </h3>
          <p className="mx-auto mt-1.5 max-w-[300px] text-[12px] leading-relaxed text-muted">
            {result.detail}
          </p>
          {isOnline && (
            <p className="code-chip mt-3 text-[10.5px] font-bold tracking-[0.14em] text-muted/70">
              ODA #{session.roomCode}
            </p>
          )}
        </div>
        <div className="mt-5 space-y-2">
          <button type="button" onClick={requestRematch} className="btn-gold w-full !py-3 !text-[12.5px]">
            <RotateCcw className="h-4 w-4" />
            {isOnline ? (sentRematch ? "Teklif gönderildi…" : "Yeni oyun iste") : "Tekrar oyna"}
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setResultDismissed(true)}
              className="btn-ghost !py-2.5 !text-[11.5px]"
            >
              Tahtayı incele
            </button>
            <button type="button" onClick={onExit} className="btn-ghost !py-2.5 !text-[11.5px]">
              Ana sayfa
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
