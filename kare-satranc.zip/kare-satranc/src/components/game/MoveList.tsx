import { useEffect, useRef } from "react";
import { History } from "lucide-react";
import type { Move } from "chess.js";
import { groupMoves } from "@/lib/chess";
import { cn } from "@/utils/cn";

type Props = {
  moves: Move[];
  opening: string;
  playerColor: "w" | "b";
};

export function MoveList({ moves, opening, playerColor }: Props) {
  const rows = groupMoves(moves);
  const scroller = useRef<HTMLDivElement>(null);
  const lastIndex = moves.length - 1;

  useEffect(() => {
    const node = scroller.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [moves.length]);

  if (moves.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 py-12 text-center">
        <span className="grid h-11 w-11 place-items-center rounded-full border border-line/80 bg-ink-800/70">
          <History className="h-5 w-5 text-muted/70" />
        </span>
        <div>
          <p className="text-[12.5px] font-semibold text-cream-dim">Henüz hamle yok</p>
          <p className="mt-1 max-w-[200px] text-[11px] leading-relaxed text-muted">
            İlk hamleyi yaptığında tüm hamle geçmişi burada görünecek.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div ref={scroller} className="panel-scroll flex-1 overflow-y-auto px-2 py-2">
      <div className="grid grid-cols-[30px_1fr_1fr] gap-1 px-1.5 pb-1.5">
        <span className="text-[9px] font-bold tracking-wider text-muted/60 uppercase">No</span>
        <span className="flex items-center gap-1 text-[9px] font-bold tracking-wider text-muted/60 uppercase">
          Beyaz
        </span>
        <span className="text-[9px] font-bold tracking-wider text-muted/60 uppercase">Siyah</span>
      </div>
      <div className="space-y-0.5">
        {rows.map((row) => {
          const whiteIndex = (row.number - 1) * 2;
          const blackIndex = whiteIndex + 1;
          return (
            <div
              key={row.number}
              className="grid grid-cols-[30px_1fr_1fr] items-center gap-1 rounded-md px-1.5 py-1 transition-colors hover:bg-cream/[0.025]"
            >
              <span className="text-[10px] font-semibold text-muted/55">{row.number}.</span>
              {row.white ? (
                <MoveCell
                  san={row.white.san}
                  active={lastIndex === whiteIndex}
                  isMine={playerColor === "w"}
                />
              ) : (
                <span />
              )}
              {row.black ? (
                <MoveCell
                  san={row.black.san}
                  active={lastIndex === blackIndex}
                  isMine={playerColor === "b"}
                />
              ) : (
                <span />
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex items-center justify-between gap-2 border-t border-line/60 px-1.5 pt-2.5">
        <span className="text-[9.5px] font-semibold tracking-wider text-muted/70 uppercase">
          {opening}
        </span>
        <span className="text-[9.5px] text-muted/60">{moves.length} hamle</span>
      </div>
    </div>
  );
}

function MoveCell({ san, active, isMine }: { san: string; active: boolean; isMine: boolean }) {
  return (
    <span className="flex items-center gap-1">
      <span
        className={cn(
          "rounded px-1.5 py-0.5 font-mono text-[11.5px] font-medium transition-colors",
          active
            ? "bg-brass-300/15 text-brass-100 ring-1 ring-brass-300/20"
            : "text-cream-dim/90"
        )}
      >
        {san}
      </span>
      {active && isMine && <span className="h-1 w-1 rounded-full bg-brass-300/80" />}
    </span>
  );
}
