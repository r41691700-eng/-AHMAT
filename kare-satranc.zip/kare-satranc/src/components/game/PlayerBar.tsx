import { Bot, WifiOff } from "lucide-react";
import type { Color, PieceSymbol } from "chess.js";
import { PIECE_GLYPH, PIECE_VALUE, sortCaptures } from "@/lib/chess";
import { cn } from "@/utils/cn";

type Props = {
  name: string;
  color: Color;
  isMe: boolean;
  isTurn: boolean;
  captured: PieceSymbol[];
  advantage: number;
  connected: boolean;
  roleLabel: string;
  isBot?: boolean;
  thinking?: boolean;
  gameOver?: boolean;
};

export function PlayerBar({
  name,
  color,
  isMe,
  isTurn,
  captured,
  advantage,
  connected,
  roleLabel,
  isBot,
  thinking,
  gameOver,
}: Props) {
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toLocaleUpperCase("tr-TR"))
    .join("");
  const sorted = sortCaptures(captured);
  const capturedValue = sorted.reduce((total, piece) => total + PIECE_VALUE[piece], 0);

  return (
    <div
      className={cn(
        "flex items-center gap-3 rounded-2xl border px-3 py-2.5 transition-colors duration-300 sm:px-3.5",
        isTurn && !gameOver
          ? "border-brass-300/35 bg-gradient-to-r from-brass-300/[0.11] to-transparent"
          : "border-line/70 bg-ink-900/55"
      )}
    >
      <div
        className={cn(
          "relative grid h-9 w-9 shrink-0 place-items-center rounded-xl border text-[12px] font-extrabold sm:h-10 sm:w-10",
          color === "w"
            ? "border-[#cbbd9e] bg-gradient-to-br from-[#f1e8d4] to-[#d8c9ab] text-[#2c3128]"
            : "border-line bg-gradient-to-br from-ink-700 to-ink-900 text-cream"
        )}
      >
        {isBot ? <Bot className="h-4 w-4" /> : initials || (color === "w" ? "B" : "S")}
        <span
          className={cn(
            "absolute -right-1 -bottom-1 grid h-[15px] w-[15px] place-items-center rounded-full border-2 border-ink-900",
            color === "w" ? "bg-[#f6efdf]" : "bg-[#1d2921]"
          )}
          aria-hidden
        >
          <svg viewBox="0 0 24 24" className="h-[10px] w-[10px]" fill="none">
            <path
              d="M5 20h14M8 16c0-2 1.5-2.4 1.5-4S7 9.8 7 8.6C7 6.6 9.2 5 12 5s5 1.6 5 3.6c0 1.2-2.5 1.8-2.5 3.4S16 14 16 16"
              stroke={color === "w" ? "#2b3328" : "#f3eee2"}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
          <p className="truncate text-[12.5px] font-bold text-cream sm:text-[13px]">
            {name}
            {isMe && (
              <span className="ml-1.5 rounded border border-brass-300/25 bg-brass-300/10 px-1 py-px text-[8px] font-bold tracking-wider text-brass-200 uppercase">
                Sen
              </span>
            )}
          </p>
          {!connected && (
            <span className="flex items-center gap-1 text-[9.5px] font-semibold text-muted">
              <WifiOff className="h-2.5 w-2.5" /> bağlı değil
            </span>
          )}
        </div>
        <div className="mt-0.5 flex min-h-[15px] items-center gap-1">
          <span className="text-[9.5px] font-semibold tracking-[0.08em] text-muted uppercase">
            {color === "w" ? "Beyaz" : "Siyah"} · {roleLabel}
          </span>
          {sorted.length > 0 && <span className="mx-1 h-2.5 w-px bg-line" />}
          <span className="flex items-center gap-px">
            {sorted.map((piece, index) => (
              <span
                key={`${piece}-${index}`}
                className={cn(
                  "grid h-[17px] w-[17px] place-items-center rounded-full border",
                  color === "w"
                    ? "border-[#b9ab8d] bg-[#e8dcc4]"
                    : "border-line bg-ink-950/90"
                )}
                title={piece}
              >
                <span
                  className={cn(
                    "piece-mini !text-[12px]",
                    color === "w" ? "piece-mini-b" : "piece-mini-w"
                  )}
                >
                  {PIECE_GLYPH[piece]}
                </span>
              </span>
            ))}
          </span>
          {capturedValue > 0 && (
            <span className="ml-1 text-[10px] font-bold text-brass-300">+{capturedValue}</span>
          )}
        </div>
      </div>

      <div className="flex shrink-0 flex-col items-end gap-1">
        {gameOver ? (
          <span className="rounded-md border border-line/80 bg-ink-800 px-2 py-1 text-[9px] font-bold tracking-wider text-muted uppercase">
            Bitti
          </span>
        ) : isTurn ? (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-brass-300/30 bg-brass-300/10 px-2 py-1 text-[9px] font-bold tracking-[0.08em] text-brass-200 uppercase">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-brass-300" />
            {thinking ? "Düşünüyor" : "Sıra"}
          </span>
        ) : (
          <span className="text-[9.5px] font-semibold tracking-wider text-muted/70 uppercase">
            Bekliyor
          </span>
        )}
        <span className="text-[8.5px] whitespace-nowrap text-muted/60">
          {advantage > 0 ? `+${advantage} materyal` : "—"}
        </span>
      </div>
    </div>
  );
}
