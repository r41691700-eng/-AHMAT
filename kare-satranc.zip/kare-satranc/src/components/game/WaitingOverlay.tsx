import { useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  Bot,
  Check,
  Copy,
  Link2,
  Loader2,
  RefreshCw,
  Send,
  Users,
} from "lucide-react";
import { shareLinkForRoom } from "@/lib/chess";
import { cn } from "@/utils/cn";

type Props = {
  code: string;
  role: "host" | "guest";
  state: "waiting" | "connecting" | "error";
  error?: string | null;
  onCopyLink: () => Promise<boolean> | void;
  onCopyCode: () => Promise<boolean> | void;
  onRetry: () => void;
  onPlayAI: () => void;
};

export function WaitingOverlay({
  code,
  role,
  state,
  error,
  onCopyLink,
  onCopyCode,
  onRetry,
  onPlayAI,
}: Props) {
  const [linkCopied, setLinkCopied] = useState(false);
  const [codeCopied, setCodeCopied] = useState(false);
  const shareLink = shareLinkForRoom(code);
  const shareText = `KARE'de iki kişilik satranç oynayalım mı? Oda kodu: ${code}`;

  const copyLink = async () => {
    await onCopyLink();
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };
  const copyCode = async () => {
    await onCopyCode();
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center rounded-[18px] bg-ink-950/78 p-3 backdrop-blur-[5px] sm:p-5">
      <div className="animate-pop panel-scroll max-h-full w-full max-w-[400px] overflow-y-auto rounded-2xl border border-brass-300/20 bg-gradient-to-b from-[#151d16]/98 to-[#0b100c]/98 p-5 shadow-[0_30px_70px_-30px_rgba(0,0,0,.95)] sm:p-6">
        {state === "error" ? (
          <>
            <div className="mb-4 flex items-center gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-red-400/25 bg-red-400/10">
                <AlertTriangle className="h-5 w-5 text-red-300" />
              </span>
              <div>
                <p className="eyebrow !text-red-300/80">Bağlantı kurulamadı</p>
                <h3 className="font-display text-xl font-semibold text-cream">
                  {role === "host" ? "Oda açılamadı" : "Odaya ulaşılamadı"}
                </h3>
              </div>
            </div>
            <p className="text-[12px] leading-relaxed text-muted">{error}</p>
            <div className="mt-5 grid gap-2">
              <button type="button" onClick={onRetry} className="btn-gold w-full !py-2.5 !text-[12.5px]">
                <RefreshCw className="h-4 w-4" />
                Yeniden dene
              </button>
              <button type="button" onClick={onPlayAI} className="btn-ghost w-full !py-2.5 !text-[12.5px]">
                <Bot className="h-4 w-4 text-brass-200" />
                Bilgisayara karşı oyna
              </button>
            </div>
            <p className="mt-4 text-center text-[10px] leading-relaxed text-muted/70">
              Kurumsal ağlar ve bazı güvenlik duvarları WebRTC bağlantısını engelleyebilir.
            </p>
          </>
        ) : state === "connecting" ? (
          <div className="text-center">
            <span className="relative mx-auto mb-5 grid h-14 w-14 place-items-center rounded-2xl border border-brass-300/25 bg-brass-300/[0.07]">
              <Loader2 className="h-6 w-6 animate-spin text-brass-200" />
            </span>
            <p className="eyebrow mb-1.5">Odaya bağlanılıyor</p>
            <h3 className="font-display text-2xl font-semibold text-cream">Kod doğrulanıyor…</h3>
            <div className="my-5 rounded-xl border border-line/80 bg-ink-950/60 px-4 py-3">
              <p className="text-[9px] font-bold tracking-[0.2em] text-muted uppercase">Oda kodu</p>
              <p className="code-chip mt-1 font-display text-2xl font-semibold text-brass-200">
                #{code}
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 text-[11.5px] text-muted">
              <span className="flex gap-1">
                {[0, 1, 2].map((dot) => (
                  <span
                    key={dot}
                    className="h-1.5 w-1.5 animate-bounce rounded-full bg-brass-300/70"
                    style={{ animationDelay: `${dot * 140}ms` }}
                  />
                ))}
              </span>
              Güvenli eşleşme kuruluyor
            </div>
            <p className="mt-3 text-[10px] leading-relaxed text-muted/60">
              Bu işlem genel ağa bağlı olarak 15 saniye sürebilir.
            </p>
          </div>
        ) : (
          <>
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="live-dot h-1.5 w-1.5 rounded-full bg-live" />
                <span className="text-[9.5px] font-bold tracking-[0.18em] text-live uppercase">
                  Oda açık
                </span>
              </div>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-line/80 bg-ink-800/70 px-2 py-0.5 text-[9px] font-bold tracking-wider text-muted uppercase">
                <Users className="h-2.5 w-2.5" /> 1 / 2
              </span>
            </div>

            <p className="eyebrow mb-1">Masa kuruldu</p>
            <h3 className="font-display text-[24px] leading-tight font-semibold text-cream">
              Rakibini bekliyoruz
            </h3>
            <p className="mt-1.5 text-[11.5px] leading-relaxed text-muted">
              Kodu arkadaşınla paylaş. Katıldığı anda oyun otomatik başlar.
            </p>

            <button
              type="button"
              onClick={copyCode}
              className="group mt-4 w-full rounded-xl border border-brass-300/25 bg-brass-300/[0.06] px-3 py-3 text-center transition hover:border-brass-300/45 hover:bg-brass-300/[0.1]"
              aria-label="Oda kodunu kopyala"
            >
              <p className="text-[8.5px] font-bold tracking-[0.22em] text-muted uppercase">
                Oda kodu
              </p>
              <p className="code-chip mt-1 flex items-center justify-center gap-2 font-display text-[30px] leading-none font-semibold text-brass-200 sm:text-[34px]">
                {code}
                {codeCopied ? (
                  <Check className="h-4 w-4 text-live" />
                ) : (
                  <Copy className="h-3.5 w-3.5 text-muted transition group-hover:text-brass-200" />
                )}
              </p>
            </button>

            <div className="mt-2.5 flex items-center justify-center gap-1.5 text-[10.5px] text-muted">
              <span className="flex gap-1">
                {[0, 1, 2].map((dot) => (
                  <span
                    key={dot}
                    className="h-1.5 w-1.5 animate-bounce rounded-full bg-brass-300/60"
                    style={{ animationDelay: `${dot * 140}ms` }}
                  />
                ))}
              </span>
              Rakip bekleniyor
            </div>

            <button
              type="button"
              onClick={copyLink}
              className={cn("btn-gold mt-4 w-full !py-2.5 !text-[12px]")}
            >
              {linkCopied ? <Check className="h-4 w-4" /> : <Link2 className="h-4 w-4" />}
              {linkCopied ? "Davet bağlantısı kopyalandı" : "Davet bağlantısını kopyala"}
            </button>

            <div className="mt-2 grid grid-cols-2 gap-2">
              <a
                href={`https://wa.me/?text=${encodeURIComponent(`${shareText}\n${shareLink}`)}`}
                target="_blank"
                rel="noreferrer"
                className="btn-ghost !px-2 !py-2 !text-[11px]"
              >
                <Send className="h-3.5 w-3.5 text-live" />
                WhatsApp
              </a>
              <a
                href={`https://t.me/share/url?url=${encodeURIComponent(shareLink)}&text=${encodeURIComponent(shareText)}`}
                target="_blank"
                rel="noreferrer"
                className="btn-ghost !px-2 !py-2 !text-[11px]"
              >
                <Send className="h-3.5 w-3.5 text-sage-300" />
                Telegram
              </a>
            </div>

            <div className="my-3.5 flex items-center gap-2 rounded-lg border border-line/60 bg-ink-950/40 px-2.5 py-2">
              <span className="piece-mini piece-mini-w !text-[17px]">♔</span>
              <p className="text-[10px] leading-snug text-muted">
                Kurucu olarak <span className="font-semibold text-cream-dim">beyaz taşlardasın</span>.
                Katılan oyuncu siyahı alır.
              </p>
            </div>

            <button
              type="button"
              onClick={onPlayAI}
              className="group flex w-full items-center justify-center gap-1.5 py-1 text-[10.5px] font-semibold text-muted transition hover:text-brass-200"
            >
              <Bot className="h-3 w-3" />
              Beklemek istemiyorum, bilgisayara karşı oyna
              <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
            </button>
          </>
        )}
      </div>
    </div>
  );
}
