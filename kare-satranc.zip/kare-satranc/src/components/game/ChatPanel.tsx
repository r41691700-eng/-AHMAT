import { useEffect, useRef } from "react";
import { Lock, Send } from "lucide-react";
import type { ChatEntry } from "@/lib/protocol";
import { cn } from "@/utils/cn";

type Props = {
  messages: ChatEntry[];
  me: string;
  onSend: (text: string) => void;
  disabled?: boolean;
  draft: string;
  setDraft: (value: string) => void;
};

function timeLabel(timestamp: number) {
  try {
    return new Date(timestamp).toLocaleTimeString("tr-TR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "";
  }
}

export function ChatPanel({ messages, me, onSend, disabled, draft, setDraft }: Props) {
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const node = scroller.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages.length]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div ref={scroller} className="panel-scroll flex-1 space-y-2.5 overflow-y-auto px-3 py-3">
        {messages.map((message) => {
          if (message.author === "system") {
            return (
              <p
                key={message.id}
                className="mx-auto max-w-[92%] text-center text-[10px] leading-relaxed font-medium text-muted/70"
              >
                {message.text}
              </p>
            );
          }
          const isMe = message.author === "me";
          return (
            <div key={message.id} className={cn("flex flex-col", isMe ? "items-end" : "items-start")}>
              <div className="mb-1 flex items-center gap-1.5 px-0.5">
                <span className="text-[9.5px] font-bold tracking-wide text-muted uppercase">
                  {isMe ? me : message.name}
                </span>
                <span className="text-[8.5px] text-muted/50">{timeLabel(message.time)}</span>
              </div>
              <div
                className={cn(
                  "max-w-[88%] rounded-xl px-3 py-2 text-[11.5px] leading-relaxed",
                  isMe
                    ? "rounded-br-sm border border-brass-300/20 bg-brass-300/[0.13] text-cream"
                    : "rounded-bl-sm border border-line/80 bg-ink-800 text-cream-dim"
                )}
              >
                {message.text}
              </div>
            </div>
          );
        })}
        {messages.length === 0 && (
          <div className="flex h-full min-h-[140px] flex-col items-center justify-center gap-2 px-6 text-center">
            <span className="grid h-9 w-9 place-items-center rounded-full border border-line/80 bg-ink-800/60">
              <Send className="h-3.5 w-3.5 text-muted/70" />
            </span>
            <p className="text-[11.5px] leading-relaxed text-muted">
              Masada sohbet serbest.
              <br />
              İlk mesajı sen yaz.
            </p>
          </div>
        )}
      </div>

      {disabled ? (
        <div className="flex items-center justify-center gap-2 border-t border-line/60 px-3 py-3 text-[10.5px] font-medium text-muted/70">
          <Lock className="h-3 w-3" />
          Sohbet yalnızca iki oyunculu odalarda açık
        </div>
      ) : (
        <form
          onSubmit={(event) => {
            event.preventDefault();
            onSend(draft);
          }}
          className="flex items-center gap-2 border-t border-line/60 p-2.5"
        >
          <input
            value={draft}
            onChange={(event) => setDraft(event.target.value.slice(0, 180))}
            placeholder="Bir şey yaz…"
            aria-label="Sohbet mesajı"
            className="field !rounded-lg !border-line/70 !bg-ink-950/50 !px-3 !py-2 !text-[11.5px]"
          />
          <button
            type="submit"
            disabled={!draft.trim()}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-brass-300/25 bg-brass-300/10 text-brass-200 transition hover:bg-brass-300/20 disabled:opacity-35"
            aria-label="Mesajı gönder"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        </form>
      )}
    </div>
  );
}
