import { useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import type { Color, Square } from "chess.js";
import {
  FILES,
  PIECE_GLYPH,
  PIECE_NAME_TR,
  buildGame,
  type PieceSymbol,
} from "@/lib/chess";
import {
  squareOffsets,
  trackPieces,
  type CapturedPiece,
} from "@/lib/pieceAnimation";
import { cn } from "@/utils/cn";

export type BoardMove = { from: string; to: string; promotion?: string };

type Props = {
  history: string[];
  orientation: Color;
  myColor: Color;
  interactive: boolean;
  onMove: (move: BoardMove) => void;
  onBlocked?: (reason: "turn" | "waiting" | "over") => void;
  className?: string;
};

type MoveFlash = {
  token: number;
  from: string;
  to: string;
  promotion: boolean;
};

const PROMOTION_OPTIONS: { piece: PieceSymbol; label: string }[] = [
  { piece: "q", label: "Vezir" },
  { piece: "r", label: "Kale" },
  { piece: "b", label: "Fil" },
  { piece: "n", label: "At" },
];

export function ChessBoard({
  history,
  orientation,
  myColor,
  interactive,
  onMove,
  onBlocked,
  className,
}: Props) {
  const [selected, setSelected] = useState<string | null>(null);
  const [promotion, setPromotion] = useState<{ from: string; to: string } | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [ghosts, setGhosts] = useState<CapturedPiece[]>([]);
  const [activeIds, setActiveIds] = useState<string[]>([]);
  const [flash, setFlash] = useState<MoveFlash | null>(null);
  const [epoch, setEpoch] = useState(0);
  const previousLength = useRef(history.length);

  const game = useMemo(() => buildGame(history), [history]);
  const tracked = useMemo(() => trackPieces(history), [history]);
  const myTurn = game.turn() === myColor;
  const gameOver = game.isGameOver();

  useEffect(() => {
    setSelected(null);
    setPromotion(null);
  }, [history.length]);

  // Motion state is purely visual: it is derived from the new history but never
  // feeds back into game state, validation or networking.
  useLayoutEffect(() => {
    const previous = previousLength.current;
    previousLength.current = history.length;

    if (history.length <= previous || history.length - previous > 1) {
      setGhosts([]);
      setActiveIds([]);
      setFlash(null);
      // Remount pieces on a reset/resync so they appear on their new squares
      // instead of sliding there from the previous game.
      setEpoch((value) => value + 1);
      return;
    }

    const trace = tracked.lastMove;
    if (!trace) return;

    setGhosts(trace.captured);
    setActiveIds(trace.movedIds);
    setFlash({
      token: Date.now(),
      from: trace.from,
      to: trace.to,
      promotion: Boolean(trace.promotion),
    });

    const clearGhosts = setTimeout(() => setGhosts([]), 520);
    const clearActive = setTimeout(() => setActiveIds([]), 520);
    const clearFlash = setTimeout(() => setFlash(null), 820);

    return () => {
      clearTimeout(clearGhosts);
      clearTimeout(clearActive);
      clearTimeout(clearFlash);
    };
  }, [history.length, tracked]);

  const verbose = useMemo(() => game.history({ verbose: true }), [game]);
  const last = verbose[verbose.length - 1];
  const lastMove = last ? { from: last.from, to: last.to } : null;
  const lastPromotionSquare = last?.flags.includes("p") ? last.to : null;

  const legalTargets = useMemo(() => {
    if (!selected) return new Map<string, { promotion?: boolean }>();
    const map = new Map<string, { promotion?: boolean }>();
    const moves = game.moves({ square: selected as Square, verbose: true });
    for (const move of moves) {
      const current = map.get(move.to);
      map.set(move.to, { promotion: current?.promotion || Boolean(move.promotion) });
    }
    return map;
  }, [game, selected]);

  const checkSquare = useMemo(() => {
    if (!game.isCheck()) return null;
    const targetColor = game.turn();
    for (const row of game.board()) {
      for (const cell of row) {
        if (cell && cell.type === "k" && cell.color === targetColor) return cell.square;
      }
    }
    return null;
  }, [game]);

  const rows = game.board();
  const cells = rows.flatMap((row, rowIndex) =>
    row.map((cell, fileIndex) => ({
      cell,
      square: `${FILES[fileIndex]}${8 - rowIndex}`,
      fileIndex,
      rank: 8 - rowIndex,
    }))
  );
  const displayCells = orientation === "w" ? cells : [...cells].reverse();

  const positionStyle = (square: string) => {
    const { col, row } = squareOffsets(square, orientation);
    return {
      "--tx": `${col * 100}%`,
      "--ty": `${row * 100}%`,
    } as CSSProperties;
  };

  const commit = (from: string, to: string, promotionPiece?: string) => {
    setSelected(null);
    setPromotion(null);
    onMove({ from, to, promotion: promotionPiece });
  };

  const handleSquareClick = (square: string, piece: { color: Color; type: PieceSymbol } | null) => {
    if (promotion) return;
    if (!interactive) {
      if (piece?.color === myColor) onBlocked?.(gameOver ? "over" : myTurn ? "waiting" : "turn");
      return;
    }
    if (!myTurn) {
      if (piece?.color === myColor) onBlocked?.("turn");
      return;
    }

    const activeSelection = selected;
    if (activeSelection) {
      if (square === activeSelection) {
        setSelected(null);
        return;
      }
      const target = legalTargets.get(square);
      if (target) {
        if (target.promotion) {
          setPromotion({ from: activeSelection, to: square });
        } else {
          commit(activeSelection, square);
        }
        return;
      }
      if (piece?.color === myColor) {
        setSelected(square);
        return;
      }
      setSelected(null);
      return;
    }

    if (piece?.color === myColor) {
      setSelected(square);
    }
  };

  const orientationLabel =
    orientation === myColor ? "Kendi yönünden" : "Rakip yönünden";

  return (
    <div
      className={cn(
        "board-frame w-full transition-shadow duration-500",
        checkSquare && "board-in-check",
        className
      )}
    >
      <div className="board-surface relative overflow-hidden rounded-[10px]">
        <div
          className="board-grid"
          role="grid"
          aria-label={`Satranç tahtası, ${orientationLabel}`}
          onMouseLeave={() => setHovered(null)}
        >
          {displayCells.map(({ cell, square, fileIndex, rank }, index) => {
            const isLight = (fileIndex + (rank - 1)) % 2 === 1;
            const isSelected = selected === square;
            const isLast = lastMove?.from === square || lastMove?.to === square;
            const isCheck = checkSquare === square;
            const isPromotion = lastPromotionSquare === square;
            const target = legalTargets.get(square);
            const isTarget = Boolean(target);
            const isCapture = isTarget && Boolean(cell);
            const isBottom = index >= 56;
            const isLeft = index % 8 === 0;
            const canSelect =
              interactive && myTurn && cell?.color === myColor && !gameOver;

            return (
              <button
                type="button"
                key={square}
                role="gridcell"
                aria-label={
                  cell
                    ? `${square}, ${cell.color === "w" ? "beyaz" : "siyah"} ${PIECE_NAME_TR[cell.type]}`
                    : `${square}, boş`
                }
                aria-selected={isSelected}
                onClick={() =>
                  handleSquareClick(square, cell ? { color: cell.color, type: cell.type } : null)
                }
                onMouseEnter={() => setHovered(square)}
                onFocus={() => setHovered(square)}
                onBlur={() => setHovered(null)}
                className={cn(
                  "sq",
                  isLight ? "sq-light" : "sq-dark",
                  (canSelect || (isTarget && interactive)) && "sq-playable",
                  isLast && "sq-last",
                  isSelected && "sq-selected",
                  isCheck && "sq-check",
                  isTarget && !isCapture && "sq-dot",
                  isCapture && "sq-capture",
                  isPromotion && "sq-promotion"
                )}
              >
                {isLeft && (
                  <span
                    className="board-coord top-1 left-1.5"
                    style={{ color: isLight ? "#66735f" : "#efe7d6" }}
                  >
                    {rank}
                  </span>
                )}
                {isBottom && (
                  <span
                    className="board-coord right-1.5 bottom-1"
                    style={{ color: isLight ? "#66735f" : "#efe7d6" }}
                  >
                    {FILES[fileIndex]}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Animated pieces live in their own pointer-transparent layer so that
            a piece can glide across square boundaries between renders. */}
        <div className="board-pieces" aria-hidden="true">
          {flash && (
            <span
              key={`flash-${flash.token}`}
              className={cn("move-flash", flash.promotion && "is-promotion")}
              style={positionStyle(flash.to)}
            />
          )}

          {ghosts.map((ghost) => (
            <span
              key={`ghost-${ghost.id}-${flash?.token ?? "still"}`}
              className={cn(
                "piece-ghost",
                ghost.color === "w" ? "piece-w" : "piece-b"
              )}
              style={positionStyle(ghost.square)}
            >
              <span className="piece-glyph">{PIECE_GLYPH[ghost.type]}</span>
            </span>
          ))}

          {tracked.pieces.map((piece) => {
            const isMoving = activeIds.includes(piece.id);
            const isSelected = selected === piece.square;
            const isHovered = hovered === piece.square;
            return (
              <span
                key={`${piece.id}-${epoch}`}
                className={cn(
                  "piece-anim",
                  piece.color === "w" ? "piece-w" : "piece-b",
                  isMoving && "is-moving",
                  isSelected && "is-selected",
                  isHovered && "is-hovered"
                )}
                style={positionStyle(piece.square)}
              >
                <span className="piece-glyph">{PIECE_GLYPH[piece.type]}</span>
              </span>
            );
          })}
        </div>
      </div>

      {promotion && (
        <div className="absolute inset-0 z-20 grid place-items-center rounded-[18px] bg-ink-950/60 p-4 backdrop-blur-[3px]">
          <div className="animate-pop w-full max-w-[280px] rounded-2xl border border-brass-300/25 bg-ink-850/95 p-3 shadow-2xl sm:max-w-[320px]">
            <div className="mb-2 flex items-center justify-between px-1">
              <p className="text-[11px] font-bold tracking-[0.16em] text-brass-200 uppercase">
                Piyon terfi ediyor
              </p>
              <button
                type="button"
                onClick={() => setPromotion(null)}
                className="text-[11px] font-semibold text-muted transition hover:text-cream"
              >
                Vazgeç
              </button>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {PROMOTION_OPTIONS.map(({ piece, label }) => (
                <button
                  key={piece}
                  type="button"
                  onClick={() => commit(promotion.from, promotion.to, piece)}
                  className="group flex flex-col items-center gap-1 rounded-xl border border-line/80 bg-ink-800 px-1 py-2 transition hover:border-brass-300/50 hover:bg-ink-700"
                >
                  <span
                    className={cn(
                      "piece-mini !text-[30px]",
                      myColor === "w" ? "piece-mini-w" : "piece-mini-b"
                    )}
                  >
                    {PIECE_GLYPH[piece]}
                  </span>
                  <span className="text-[10px] font-semibold text-muted group-hover:text-cream">
                    {label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
