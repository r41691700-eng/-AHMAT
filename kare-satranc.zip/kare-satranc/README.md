# KARE — İki Kişilik Online Satranç

KARE, tarayıcıda çalışan, sunucusuz (P2P) iki kişilik bir satranç uygulamasıdır.
Bir oda kurup 6 haneli kodu paylaşarak arkadaşınla gerçek zamanlı satranç oynayabilirsin.
Üyelik, veritabanı veya kendi sunucun gerekmez.

**Canlı demo:** https://thunder-quality-xdx9q.ship.place/
**Paket:** Bu arşiv; kaynak kodun tamamını, üretim çıktısını ve dokümantasyonu içerir.

---

## İçindekiler

- [Özellikler](#özellikler)
- [Teknolojiler](#teknolojiler)
- [Hızlı başlangıç](#hızlı-başlangıç)
- [Build ve yayın](#build-ve-yayın)
- [Nasıl oynanır](#nasıl-oynanır)
- [Proje yapısı](#proje-yapısı)
- [Bağlantı mimarisi](#bağlantı-mimarisi)
- [Bilinen sınırlar](#bilinen-sınırlar)
- [Lisans](#lisans)

---

## Özellikler

- **Oda sistemi:** "Oda Kur" rastgele 6 haneli bir kod üretir (ör. `#X8K2M9`).
  Kurucu beyaz, odaya katılan siyah taşlarla oynar.
- **Davet bağlantısı:** `?oda=KOD` parametresi kod alanını otomatik doldurur.
- **Gerçek zamanlı eşleşme:** PeerJS (WebRTC) ile iki tarayıcı arasında doğrudan,
  şifreli veri kanalı. Hamleler, sohbet, beraberlik/terk istekleri ve rövanş anlık senkronize olur.
- **Tam satranç kuralları:** `chess.js` ile şah, mat, pat, rok, geçerken alma,
  piyon terfisi, 50 hamle ve üç tekrar kuralları.
- **Modern arayüz:** Koyu yeşil + pirinç temalı, serif başlıklı özgün tasarım;
  masaüstü ve mobil uyumlu.
- **Animasyonlu tahta:** Taşlar kareler arasında kayar; alınan taş sönümlenir,
  seçili taş ve geçerli hamleler parıltı/nokta ile, son hamle kehribar vurgu ile gösterilir.
- **Oyun paneli:** Sıra göstergesi, şah/mat/beraberlik mesajları, açılış adı,
  hamle listesi, alınan taşlar ve materyal avantajı.
- **Sohbet ve ses:** Oda içi mesajlaşma; hamle, şah, alma ve oyun sonu ses efektleri
  (istenirse kapatılabilir).
- **Tek cihaz modu:** Rakip yoksa "Bilgisayara karşı oyna" seçeneğiyle minimax tabanlı yapay zekâya karşı oynanabilir.
- **Erişilebilirlik:** Klavye ile gezilebilir kareler, anlamlı `aria-label`'lar
  ve `prefers-reduced-motion` desteği.

## Teknolojiler

| Katman | Teknoloji |
| --- | --- |
| Arayüz | React 19, TypeScript 5.9 |
| Stil | Tailwind CSS 4, özel CSS (animasyonlar, tahta) |
| Build | Vite 7, `vite-plugin-singlefile` (tek HTML çıktısı) |
| Satranç kuralları | chess.js 1.4 |
| Gerçek zamanlı bağlantı | PeerJS 1.5 / WebRTC |
| İkonlar | lucide-react |
| Yazı tipleri | Fraunces, Manrope, Noto Sans Symbols 2 (Google Fonts) |

> Not: Yazı tipleri ve PeerJS'in eşleşme sunucusu internet üzerinden çalışır.
> Uygulamanın kendi backend'i yoktur; satranç mantığı tamamen tarayıcıda çalışır.

## Hızlı başlangıç

Gereksinim: **Node.js 20+** ve npm.

```bash
npm install
npm run dev
```

Terminalde yazan adresi aç (genellikle `http://localhost:5173`).

Yeniden oyun sunucusu gerekmez; ikinci bir tarayıcı sekmesi/penceresi ile oda testi yapabilirsin.

### Hazır build

Arşivde `dist/index.html` olarak üretilmiş tek dosyalık sürüm de bulunur.
Bu dosya herhangi bir statik sunucuda yayınlanabilir:

```bash
npx serve dist
# veya
python3 -m http.server 4173 --directory dist
```

> `file://` üzerinden açmak yerine bir HTTP sunucusu kullanman önerilir;
> WebRTC ve PeerJS bağlantıları için `localhost` veya HTTPS gerekir.

## Build ve yayın

```bash
npm run build     # üretim çıktısı: dist/index.html
npm run preview   # build'i yerelde önizle
npx tsc --noEmit  # tip kontrolü
```

Çıktı tek bir `dist/index.html` dosyasıdır. Vercel, Netlify, Cloudflare Pages,
GitHub Pages veya herhangi bir statik hosting'e doğrudan yüklenebilir.
Uygulama istemci tarafında çalıştığı için ek ortam değişkeni ya da API anahtarı gerekmez.

## Nasıl oynanır

1. Bağlantıyı aç, adını yaz ve **Oda Kur**'a bas.
2. Ekranda görünen 6 haneli kodu ya da "Davet bağlantısını kopyala" seçeneğini arkadaşına gönder.
3. Arkadaşın **Odaya Katıl**'a basıp kodu girer.
4. İki taraf bağlanınca oyun otomatik başlar. Sırası gelen kendi rengiyle hamle yapar.
5. Hamle sırası, şah, mat ve beraberlik durumları sağ panelde anlık görünür.

Kurucu **beyaz**, katılan oyuncu **siyah** taşlardadır. "Tahtayı çevir" yalnızca
görünümü değiştirir, taş rengini etkilemez.

## Proje yapısı

```
.
├── index.html                  # Vite giriş şablonu
├── package.json
├── tsconfig.json
├── vite.config.ts              # Tailwind + singlefile + @ alias
├── README.md
├── LICENSE
├── dist/
│   └── index.html              # üretilmiş tek dosyalık uygulama
└── src/
    ├── main.tsx                # React kökü
    ├── App.tsx                 # ekran/oturum yönlendirme
    ├── index.css               # tema, tahta, animasyonlar
    ├── components/
    │   ├── HomeScreen.tsx      # ana ekran, oda kur/katıl, tanıtım
    │   ├── GameRoom.tsx        # masa, hamle/game akışı, PeerJS oturumu
    │   ├── ChessBoard.tsx      # tahta, seçim, terfi, animasyon katmanı
    │   ├── ui.tsx              # logo, modal, bildirimler
    │   └── game/
    │       ├── PlayerBar.tsx   # oyuncu şeritleri
    │       ├── MoveList.tsx    # hamle geçmişi
    │       ├── ChatPanel.tsx   # sohbet
    │       └── WaitingOverlay.tsx # oda kodu / rakip bekleme / hata
    ├── hooks/
    │   ├── usePeerGame.ts      # PeerJS oda açma/katılma katmanı
    │   └── useToasts.ts        # bildirim yönetimi
    ├── lib/
    │   ├── chess.ts            # chess.js yardımcıları, oda kodu, paylaşım
    │   ├── pieceAnimation.ts   # animasyon için sabit taş kimlikleri
    │   ├── protocol.ts         # P2P mesaj tipleri ve sohbet modeli
    │   ├── ai.ts               # bilgisayar rakibi (minimax)
    │   ├── session.ts          # oturum tipleri
    │   └── sound.ts            # Web Audio efektleri
    └── utils/cn.ts             # sınıf birleştirme
```

## Bağlantı mimarisi

1. Kurucu, oda kodundan türetilen deterministik bir PeerJS kimliğiyle
   (`kare-satranc-v1-<kod>`) odayı açar.
2. Katılan oyuncu aynı kimliğe bağlanır; WebRTC veri kanalı kurulur.
3. Oyun durumu, hamle geçmişi (SAN dizisi) üzerinden taşınır.
   Sunucu otoritesi yoktur; iki taraf da aynı geçmişi chess.js ile doğrular.
4. Sıra dışı hamleler kural motoru tarafından reddedilir; tutarsız geçmişlerde
   taraflar birbirinden yeniden senkronizasyon ister.
5. Sohbet, beraberlik teklifi, terk ve rövanş aynı veri kanalından iletilir.

PeerJS'in ücretsiz açık eşleşme sunucusu ve genel STUN sunucuları kullanılır.
Kurumsal ağlar veya simetrik NAT'lar doğrudan bağlantıyı engelleyebilir; bu durumda
uygulama hata panelinden bilgisayara karşı oynamaya geçilebilir. Üretimde yüksek
güvenilirlik için kendi PeerJS sunucunu/TURN servisini ekleyebilirsin
(`src/hooks/usePeerGame.ts` içindeki `config`).

## Bilinen sınırlar

- Aynı anda bir odada yalnızca iki oyuncu bulunabilir.
- Oda kodu tarayıcı oturumuna bağlıdır; kurucu ayrılırsa masa kapanır.
- Hamle geçmişi sunucuda saklanmaz; sayfa yenilenirse oyun durumu sıfırlanır.
- Anonymous statik yayınlarda süre sınırı olabilir; kalıcı yayın için kendi hesabına deploy et.

## Lisans

MIT — bkz. [LICENSE](./LICENSE). Ticari ve kişisel projelerde özgürce kullanabilirsin.
